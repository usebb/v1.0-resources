<?php

/*
	Copyright (C) 2003-2006 UseBB Team
	http://www.usebb.net
	
	$Header: /cvsroot/usebb/UseBB/languages/lang_English.php,v 1.109 2006/01/07 14:02:27 pc_freak Exp $
	
	This file is part of UseBB.
	
	UseBB is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 2 of the License, or
	(at your option) any later version.
	
	UseBB is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.
	
	You should have received a copy of the GNU General Public License
	along with UseBB; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/*
	Author : kiplantt
	E-mail : kiplantt@yahoo.fr
	Date : 15/03/2006
	UseBB version : 0.8a
*/

//
// Die when called directly in browser
//
if ( !defined('INCLUDED') )
	exit();

//
// Initialize a new translations holder array
//
$lang = array();

//
// Translation settings
// Uncomment and change when necessary for translations
//
#$lang['character_encoding'] = 'iso-8859-1';
#$lang['language_code'] = 'en';
#$lang['text_direction'] = 'ltr';

//
// Define translations
//
$lang['Home'] = 'Index';
$lang['YourPanel'] = 'Panel';
$lang['Register'] = 'Inscription';
$lang['FAQ'] = 'FAQ';
$lang['Search'] = 'Recherche';
$lang['ActiveTopics'] = 'Discussions actives';
$lang['LogIn'] = 'S\'identifier';
$lang['LogOut'] = 'D�connexion (%s)';
$lang['MemberList'] = 'Liste des membres';
$lang['StaffList'] = 'Liste de l\'�quipe';
$lang['Statistics'] = 'Statistiques';
$lang['ContactAdmin'] = 'Contacter l\'admin';
$lang['Forum'] = 'Forum';
$lang['Topics'] = 'Discussions';
$lang['Posts'] = 'Messages';
$lang['LatestPost'] = 'Derniers messages';
$lang['RSSFeed'] = 'Fil RSS';
$lang['NewPosts'] = 'Nouveaux messages';
$lang['NoNewPosts'] = 'Aucun nouveau message';
$lang['LockedNewPosts'] = 'Ferm� (nouveaux messages)';
$lang['LockedNoNewPosts'] = 'Ferm� (aucun nouveau message)';
$lang['Locked'] = 'Ferm�';
$lang['LastLogin'] = 'Derni�re identification';
$lang['VariousInfo'] = 'Informations diverses';
$lang['IndexStats'] = 'Ces forums contiennent %d message dans %d discussions et a %d membres inscrits.';
$lang['NewestMemberExtended'] = 'Bienvenue � notre membre le plus r�cent: %s.';
$lang['Username'] = 'Nom d\'utilisateur';
$lang['CurrentPassword'] = 'Mot de passe actuel';
$lang['UserID'] = 'ID utilisateur';
$lang['NoSuchForum'] = 'Le forum %s n\'existe pas (plus) !';
$lang['WrongPassword'] = 'D�sol�, mais ce mot de passe est incorrect ! Veuillez demander un nouveau mot de passe via le formulaire d\'identification si vous l\'avez oubli�.';
$lang['Reset'] = 'Remettre � z�ro';
$lang['SendPassword'] = 'Envoyer un nouveau mot de passe';
$lang['RegisterNewAccount'] = 'S\'inscrire';
$lang['RememberMe'] = 'Se rappeler de moi';
$lang['Yes'] = 'Oui';
$lang['No'] = 'Non';
$lang['NotActivated'] = 'Votre compte %s n\'a pas encore �t� activ�. Veuillez regarder dans votre bo�te mail avec laquelle vous vous �tes enregistr� sur ces forums pour savoir comment activer votre compte.';
$lang['Error'] = 'Erreur';
$lang['Profile'] = 'Profil de %s';
$lang['Level'] = 'Niveau';
$lang['Administrator'] = 'Administrateur';
$lang['Moderator'] = 'Mod�rateur';
$lang['Registered'] = 'Inscrits';
$lang['Email'] = 'Adresse e-mail';
$lang['ContactInfo'] = 'Informations de contact';
$lang['Password'] = 'Mot de passe';
$lang['PasswordAgain'] = 'Mot de passe (v�rification)';
$lang['EverythingRequired'] = 'Tous les champs sont requis !';
$lang['RegisteredNotActivated'] = 'Votre compte %s a �t� cr��. Un e-mail a �t� envoy� � %s avec les instructions pour activer votre compte. Vous �tre oblig� de l\'activer avant de pouvoir vous identifier.';
$lang['RegisteredActivated'] = 'Votre compte %s a �t� cr��. Vous pouvez vous identifier sans attendre.';
$lang['Never'] = 'Jamais';
$lang['Member'] = 'Membre';
$lang['RegistrationActivationEmailBody'] = 'Bonjour,

Cet e-mail provient des forums [board_name]. Vous vous �tes inscrit en tant que [account_name], mais ce compte n\'a pas encore �t� activ�. Pour ce faire, cliquez sur le lien d\'activation ci-dessous:

[activate_link]

ou copiez-collez-le dans votre navigateur. Cela fait, vous pouvez vous identifier avec ce nom d\'utilisateur et mot de passe:

Nom d\'utilisateur: [account_name]
Mot de passe: [password]

Si vous oubliez votre mot de passe, vous pouvez en demander un nouveau via le lien du formulaire d\'identification. Merci de vous �tre inscrit !

[board_name]
[board_link]
[admin_email]';
$lang['NoForums'] = 'Forums vides. L\'administrateur n\'a pas encore cr�� de forum.';
$lang['AlreadyActivated'] = 'Le compte avec l\'ID %d a d�j� �t� activ�.';
$lang['Activate'] = 'Activer';
$lang['Activated'] = 'Votre compte %s vient d\'�tre (r�)activ�. Vous pouvez maintenant vous identifier avec votre nom d\'utilisateur et mot de passe.';
$lang['WrongActivationKey'] = 'Nous n\'avons pas pu activ� votre compte avec l\'ID %d. La cl� d\'activation est incorrecte. �tes-vous s�re que vous n\'avez pas demand� un autre mot de passe entre-temps ?';
$lang['RegisterIt'] = 'Vous pouvez le cr�er via le lien "Inscription".';
$lang['BoardClosed'] = 'Forums ferm�s';
$lang['SendpwdEmailBody'] = 'Bonjour,

Cet e-mail provient des forums [board_name]. Vous venez de demander un nouveau mot de passe pour le compte [account_name]. Vous pouvez vous identifier en utilisant ce nom d\'utilisateur et mot de passe:

Nom d\'utilisateur: [account_name]
Mot de passe: [password]

Si vous oubliez votre mot de passe, vous pouvez en demander un nouveau via le lien du formulaire d\'identification.

[board_name]
[board_link]
[admin_email]';
$lang['SendpwdEmailSubject'] = 'Nouveau mot de passe';
$lang['SendpwdActivated'] = 'Le nouveau mot de passe pour votre compte %s a �t� envoy� � %s. Vous avez maintenant la possibilit� de vous identifier avec votre nouveau mot de passe.';
$lang['ForumIndex'] = 'Index';
$lang['MissingFields'] = 'Les champs obligatoires suivants �taient manquants ou incorrects: %s.';
$lang['TermsOfUseContent'] = 'Vous approuvez que tous les messages de ce forum sont le reflet des opinions de leurs auteurs et non du webmaster, de l\'administrateur ou des mod�rateurs, sauf dans le cas de message �crits par eux.

Vous vous engagez � ne pas poster de contenu ill�gal, offensant ou obsc�ne sur ce forum. Dans le cas contraire, vous pouvez �tre banni, et votre FAI pourra �tre pr�venu de votre comportement. Pour ce faire, votre adresse IP est associ�e � chaque message que vous postez. Vous acceptez �galement que vos messages puissent �tre supprim�s, modifi�s, d�plac�s ou ferm�s par les administrateurs ou mod�rateurs s\'ils l\'estiment n�cessaire.

Toutes les informations que vous postez sur ce forum son conserv�es dans une base de donn�es. Ces informations ne seront pas redistribu�es par l\'administrateur sans votre permission. Cependant, ni le webmaster, ni l\'administrateur, ni les mod�rateurs, ni l\'�quipe de UseBB ne pourra �tre tenu responsable de la fuite des informations dans le cas d\'un piratage.

Ce forum utilise des cookies pour enregistrer des informations temporaires, n�cessaires au syst�me, sur votre ordinateur. Un cookie peut �galement contenir votre ID utilisateur et votre mot de passe crypt� pour permettre l\'identification automatique lorsque vous activez cette option. Si vous ne voulez pas que des cookies soient enregistr�s sur votre ordinateur, r�f�rez vous au manuel de votre navigateur pour savoir comment les bloquer.

En appuyant sur le bouton "J\'accepte", vous acceptez ces conditions d\'utilisation.';
$lang['TermsOfUse'] = 'Condition d\'utilisation';
$lang['RegistrationActivationEmailSubject'] = 'Activation';
$lang['NeedToBeLoggedIn'] = 'Vous devez �tre identifi� pour faire cela. Cliquez sur le lien "S\'identifier" pour vous identifier ou sur "Inscription" pour cr�er un nouveau compte.';
$lang['WrongEmail'] = 'D�sol�, mais %s n\'est pas l\'adresse e-mail correcte pour votre compte %s. Si vous n\'arrivez pas � vous rappeler votre adresse e-mail, contactez l\'administrateur.';
$lang['Topic'] = 'Discussion';
$lang['Author'] = 'Auteur';
$lang['Replies'] = 'R�ponses';
$lang['Views'] = 'Vues';
$lang['Note'] = 'Note';
$lang['Hidden'] = 'Cach�';
$lang['ACP'] = 'Panel d\'administration';
$lang['SendMessage'] = 'Envoyer un message';
$lang['NoViewableForums'] = 'Vous n\'avez pas la permission de voir des forums avec ce niveau d\'utilisateur. Si vous n\'�tes pas identifi�, faites-le. Si c\'est le cas, vous ne devriez problablement pas �tre ici.';
$lang['Rank'] = 'Rang';
$lang['Location'] = 'Lieu';
$lang['Website'] = 'Site Web';
$lang['Occupation'] = 'Profession';
$lang['Interests'] = 'Inter�ts';
$lang['MSNM'] = 'MSN Messenger';
$lang['YahooM'] = 'Yahoo Messenger';
$lang['AIM'] = 'AIM';
$lang['ICQ'] = 'ICQ';
$lang['Jabber'] = 'Jabber/XMPP';
$lang['BannedIP'] = 'Votre adresse IP %s a �t� bannie de ces forums.';
$lang['Avatar'] = 'Avatar';
$lang['AvatarURL'] = 'URL de l\'avatar';
$lang['BannedUser'] = 'Compte banni';
$lang['BannedUserExplain'] = 'Votre compte %s est banni de ces forums. La raison est:';
$lang['BannedUsername'] = 'Le nom d\'utilisateur %s est banni de ces forums. Veuillez en choisir un autre.';
$lang['BannedEmail'] = 'L\'adresse e-amil %s est bannie de ces forums. Veuillez en choisir une autre.';
$lang['PostsPerDay'] = 'Messages par jour';
$lang['BoardClosedOnlyAdmins'] = 'Seuls les administrateurs peuvent s\'identifier quand les forums sont ferm�s.';
$lang['NoPosts'] = 'Aucun message';
$lang['NoActivetopics'] = 'Ce forum n\'a actuellement aucune discussion active.';
$lang['AuthorDate'] = 'Par %s le %s';
$lang['ByAuthor'] = 'Par: %s';
$lang['OnDate'] = 'Le: %s';
$lang['Re'] = 'Re:';
$lang['MailForm'] = 'Envoi d\'un e-mail � %s';
$lang['SendEmail'] = 'Envoyer un message � %s';
$lang['NoMails'] = 'Cet utilisateur a d�cid� de ne recevoir aucun e-mail.';
$lang['UserEmailBody'] = 'Bonjour,

Cet e-mail provient des forums [board_name]. L\'utilisateur [username] vous a envoy� un message via nos forums.

[board_name]
[board_link]
[admin_email]

-----

[body]';
$lang['EmailSent'] = 'Votre e-mail a �t� envoy� � %s avec succ�s !';
$lang['To'] = '�';
$lang['From'] = 'De';
$lang['Subject'] = 'Sujet';
$lang['Body'] = 'Message';
$lang['Send'] = 'Envoyer';
$lang['EditProfile'] = 'Modifier le profil';
$lang['EditOptions'] = 'Modifier les pr�f�rences';
$lang['EditPasswd'] = 'Modifier le mot de passe';
$lang['PanelHome'] = 'Accueil du panel';
$lang['NewEmailNotActivated'] = 'Votre profil a �t� modifi� avec succ�s. Du fait que vous avez chang� l\'adresse e-mail de votre compte %s, vous devez le r�activer. Un e-mail a �t� envoy� � %s avec les instructions sur la mani�re de faire cela. Vous serez d�connect� pendant ce temps.';
$lang['Required'] = 'requis';
$lang['ViewProfile'] = 'Voir le profil';
$lang['NewEmailActivationEmailBody'] = 'Bonjour,

Cet e-mail provient des forums [board_name]. Vous avez chang� l\'adresse e-mail de votre compte [account_name], mais il n\'a pas encore �t� r�activ�. Pour ce faire, cliquez sur le lien de r�activation ci-dessous:

[activate_link]

ou copiez-collez-le dans votre navigateur.

Si vous oubliez votre mot de passe, vous pouvez en demander un nouveau via le lien du formulaire d\'identification.

[board_name]
[board_link]
[admin_email]';
$lang['NewEmailActivationEmailSubject'] = 'R�activation';
$lang['Signature'] = 'Signature';
$lang['SessionInfo'] = 'Informations de session';
$lang['SessionID'] = 'ID de session';
$lang['IPAddress'] = 'Adresse IP';
$lang['Seconds'] = 'secondes';
$lang['Updated'] = 'Mise � jour';
$lang['Pages'] = 'Pages';
$lang['AutoLogin'] = 'Identification automatique';
$lang['Enabled'] = 'Activ�';
$lang['Disabled'] = 'D�sactiv�';
$lang['Enable'] = 'Activer';
$lang['Disable'] = 'D�sactiver';
$lang['AutoLoginSet'] = 'Le cookie d\'identification automatique a �t� cr��.';
$lang['AutoLoginUnset'] = 'Le cookie d\'identification automatique a �t� supprim�.';
$lang['RegistrationEmailBody'] = 'Bonjour,

Cet e-mail provient des forums [board_name]. Vous vous �tes inscrit en tant que [account_name].  Vous pouvez vous identifier avec ce nom d\'utilisateur et mot de passe:

Nom d\'utilisateur: [account_name]
Mot de passe: [password]

Si vous oubliez votre mot de passe, vous pouvez en demander un nouveau via le lien du formulaire d\'identification. Merci de vous �tre inscrit !

[board_name]
[board_link]
[admin_email]';
$lang['RegistrationEmailSubject'] = 'Inscription';
$lang['PublicEmail'] = 'Adresse e-mail publique';
$lang['PublicLastLogin'] = 'Derni�re identification publique';
$lang['DateFormat'] = 'Format de date';
$lang['DateFormatHelp'] = 'La syntaxe du format de date est �quivalent � la fonction %s en PHP.';
$lang['Again'] = 'V�rification';
$lang['NewPassword'] = 'Nouveau mot de passe';
$lang['NewPasswordAgain'] = 'Nouveau mot de passe (v�rification)';
$lang['PasswordEdited'] = 'Votre mot de passe a �t� modifi� avec succ�s.';
$lang['DetailedOnlineList'] = 'Liste d�taill�e des membres en ligne';
$lang['Detailed'] = 'D�taill�';
$lang['OptionsEdited'] = 'Vos pr�f�rences ont �t� modifi�es avec succ�s.';
$lang['ProfileEdited'] = 'Votre profil a �t� modifi� avec succ�s.';
$lang['Started'] = 'Commenc�';
$lang['Minutes'] = 'minutes';
$lang['Hours'] = 'heures';
$lang['Days'] = 'jours';
$lang['Weeks'] = 'semaines';
$lang['TotalTime'] = 'Temps total';
$lang['NoTopics'] = 'Ce forum ne contient aucune discussion. Vous pouvez �tre le premier � poster !';
$lang['NotPermitted'] = 'Vous n\'avez pas les permissions appropri�es pour faire cela. En cas de doute, contactez l\'administrateur.';
$lang['Language'] = 'Langue';
$lang['Template'] = 'Template';
$lang['NoSuchMember'] = 'Le membre %s n\'existe pas (plus) sur ces forums.';
$lang['FeatureDisabledBecauseCookiesDisabled'] = 'Cette fonction est d�sactiv�e car ces forums ne peuvent pas �crire ou lire des cookies avec votre navigateur.';
$lang['LogOutConfirm'] = '�tes-vous s�r que vous voulez vous d�connecter ? Votre cookie d\'identification automatique sera supprim� !';
$lang['Cancel'] = 'Annuler';
$lang['Timezone'] = 'Fuseau horaire';
$lang['DST'] = 'Heure d\'�t�';
$lang['Sticky'] = '�pingl�';
$lang['PostNewTopic'] = 'Nouvelle discussion';
$lang['ForumIsLocked'] = 'Le forum est ferm�';
$lang['NoSuchTopic'] = 'La discussion %s n\'existe pas (plus).';
$lang['PostReply'] = '�crire une r�ponse';
$lang['TopicIsLocked'] = 'La discussion est ferm�e';
$lang['Post'] = 'Message';
$lang['Edit'] = 'Modifier';
$lang['Delete'] = 'Supprimer';
$lang['Quote'] = 'Citer';
$lang['Wrote'] = '%s a �crit';
$lang['ViewingIP'] = 'IP: %s';
$lang['TopicIsLockedExplain'] = 'La discussion dans laquelle vous essayer d\'�crire est ferm�e. Seules les personnes autoris�es peuvent toujours �crire des r�ponses.';
$lang['Content'] = 'Contenu';
$lang['Options'] = 'Options';
$lang['EnableBBCode'] = 'Activer le BBCode.';
$lang['EnableSmilies'] = 'Activer les �motic�nes.';
$lang['EnableSig'] = 'Activer la signature.';
$lang['EnableHTML'] = 'Activer l\'HTML.';
$lang['LockTopicAfterPost'] = 'Fermer la discussion.';
$lang['Guest'] = 'Invit�';
$lang['BackToPrevious'] = 'Revenir � la page pr�c�dente';
$lang['NoSuchPost'] = 'Le message %s n\'existe pas (plus).';
$lang['UserPostedImage'] = 'Image post�e par l\'utilisateur';
$lang['ForumIsLockedExplain'] = 'Ce forum est ferm�. Seules les personnes autoris�es peuvent toujours cr�er de nouvelles discussions.';
$lang['MakeTopicSticky'] = '�pingler.';
$lang['QuickReply'] = 'R�ponse rapide';
$lang['ReturnToTopicAfterPosting'] = 'Retourner � la discussion apr�s avoir r�pondu';
$lang['ModeratorList'] = 'Mod�rateurs: %s.';
$lang['Nobody'] = 'Personne';
$lang['DeleteTopic'] = 'Supprimer la discussion';
$lang['MoveTopic'] = 'D�placer la discussion';
$lang['LockTopic'] = 'Fermer la discussion';
$lang['UnlockTopic'] = 'Ouvrir la discussion';
$lang['MakeSticky'] = '�pingler la discussion';
$lang['ConfirmDeleteTopic'] = '�tes-vous s�r que vous voulez supprimer la discussion %s du forum %s ? Ceci est irr�versible !';
$lang['MakeNormalTopic'] = 'D�tacher la discussion';
$lang['OldForum'] = 'Ancien forum';
$lang['NewForum'] = 'Nouveau forum';
$lang['IAccept'] = 'J\'accepte';
$lang['IDontAccept'] = 'Je refuse';
$lang['OpenLinksNewWindow'] = 'Ouvrir les liens externes dans de nouvelles fen�tres';
$lang['HideAllAvatars'] = 'Cacher tous les avatars';
$lang['HideUserinfo'] = 'Cacher les informations utilisateurs';
$lang['HideAllSignatures'] = 'Cacher toutes les signatures';
$lang['HideFromOnlineList'] = 'Ne pas �tre pr�sent dans la liste des membres en ligne';
$lang['PageLinks'] = 'Page: %s';
$lang['Preview'] = 'Pr�visualisation';
$lang['DeletePost'] = 'Supprimer le message';
$lang['ConfirmDeletePost'] = '�tes-vous s�r que vous voulez supprimer ce message de la discussion %s ? Ceci est irr�versible !';
$lang['EditPost'] = 'Modifier le message';
$lang['PostEditInfo'] = 'Derni�re modification par %s le %s.';
$lang['PasswdInfo'] = 'Le mot de passe ne peut contenir que des caract�res alphanum�riques et doit avoir une longueur minimum de %d caract�res.';
$lang['SubscribeTopic'] = 'S\'abonner � la discussion';
$lang['UnsubscribeTopic'] = 'Se d�sabonner de la discussion';
$lang['NewReplyEmailBody'] = 'Bonjour,

Cet e-mail provient des forums [board_name]. Quelqu\'un ([poster_name]) a �crit une r�ponse dans une discussion � laquelle vous �tes abonn� ("[topic_title]"). Pour voir cette r�ponse, cliquez sur le lien suivant : [topic_link].

Cliquez sur le lien suivant si vous voulez vous d�sabonner de cette discussion (identification requise) : [unsubscribe_link].

[board_name]
[board_link]
[admin_email]';
$lang['NewReplyEmailSubject'] = 'Nouvelle r�ponse dans "%s"';
$lang['SubscribedTopic'] = 'Vous �tes maintenant abonn� � cette discussion.';
$lang['UnsubscribedTopic'] = 'Vous �tes maintenant d�sabonn� de cette discussion.';
$lang['SubscribeToThisTopic'] = 'S\'abonner � ce sujet.';
$lang['OK'] = 'Envoyer';
$lang['Subscriptions'] = 'Abonnements';
$lang['NoSubscribedTopics'] = 'Vous n\'�tes actuellement abonn� � aucune discussion.';
$lang['LatestUpdate'] = 'Derni�re mise � jour';
$lang['Unknown'] = 'Inconnu';
$lang['PostingTopic'] = 'En train d\'�crire une discussion dans %s';
$lang['PostingReply'] = 'En train d\'�crire une r�ponse dans %s';
$lang['MovingTopic'] = 'En train de d�placer la discussion %s';
$lang['DeletingTopic'] = 'En train de supprimer la discussion %s';
$lang['EditingPost'] = 'En train de modifier un message dans %s';
$lang['DeletingPost'] = 'En train de supprimer un message dans %s';
$lang['DebugMode'] = 'Mode d�boguage';
$lang['ParseTime'] = 'Temps de chargement';
$lang['ServerLoad'] = 'Charge serveur';
$lang['TemplateSections'] = 'Sections des templates';
$lang['SQLQueries'] = 'Requ�tes SQL';
$lang['RealName'] = 'Nom r�el';
$lang['Skype'] = 'Skype';
$lang['Administrators'] = 'Administrateurs';
$lang['Moderators'] = 'Moderateurs';
$lang['SortBy'] = 'Tri� par: %s';
$lang['TopicReview'] = 'Vue de la discussion';
$lang['ViewMorePosts'] = 'Voir plus de messages';
$lang['DisplayedName'] = 'Nom affich�';
$lang['UsernameInfo'] = 'Un nom d\'utilisateur ne peut contenir que des caract�res alphanum�riques, des espaces, _ et -.';
$lang['Code'] = 'Code';
$lang['Img'] = 'Img';
$lang['URL'] = 'URL';
$lang['Color'] = 'Couleur';
$lang['Size'] = 'Taille';
$lang['ViewingForum'] = 'Forum: %s';
$lang['ViewingTopic'] = 'Discussion: %s';
$lang['FloodIntervalWarning'] = 'L\'administrateur a sp�cifi� que vous ne pouvez pas �crire pendant une intervalle de %d secondes entre chaque r�ponse. Veuillez attendre et ressayer dans quelques instants.';
$lang['AutoSubscribe'] = 'Abonnement automatique';
$lang['OnPostingNewTopics'] = 'Aux discussions cr��es';
$lang['OnPostingNewReplies'] = '� chaque r�ponse envoy�es';
$lang['UnsubscribeSelected'] = 'D�sabonnement s�lectionn�';
$lang['SelectedTopicsUnsubscribed'] = 'Vous �tes maintenant d�sabonn� des discussions s�lectionn�es.';
$lang['Birthday'] = 'Anniversaire';
$lang['Age'] = '�ge';
$lang['Month'] = 'Mois';
$lang['Day'] = 'Jour';
$lang['Year'] = 'Ann�e';
$lang['PoweredBy'] = '%s est propuls� par %s';
$lang['GeneralStats'] = 'Statistiques g�n�rales';
$lang['Members'] = 'Membres';
$lang['TopicsPerDay'] = 'Discussions par jour';
$lang['MembersPerDay'] = 'Membres par jour';
$lang['BoardStarted'] = 'Commencement des forums';
$lang['BoardAge'] = '�ge des forums';
$lang['NewestMember'] = 'Membre le plus r�cent';
$lang['MostActiveTopics'] = 'Discussions les plus actives';
$lang['MostViewedTopics'] = 'Discussions les plus lues';
$lang['PostsPerMember'] = 'Messages par membre';
$lang['PostsPerForum'] = 'Messages par forum';
$lang['Categories'] = 'Cat�gories';
$lang['Forums'] = 'Forums';
$lang['TopicsPerMember'] = 'Discussions par membre';
$lang['TopicsPerForum'] = 'Discussions par forum';
$lang['MostActiveMembers'] = 'Membres les plus actifs';
$lang['MostActiveForums'] = 'Forums les plus actifs';
$lang['DisplayedNameTaken'] = 'D�sol�, %s est d�j� un nom d\'utilisateur ou nom affich�.';
$lang['SearchKeywords'] = 'Mots-clef';
$lang['SearchMode'] = 'Mode de recherche';
$lang['SearchAuthor'] = 'Auteur';
$lang['SearchForums'] = 'Dans les forums';
$lang['AllForums'] = 'Tous les forums';
$lang['AllKeywords'] = 'Tous les mots-clef';
$lang['OneOrMoreKeywords'] = 'Un ou plusieurs mots-clef';
$lang['NoSearchResults'] = 'D�sol�, mais aucun r�sultat n\'a �t� trouv� correspondant aux crit�res que vous avez entr�.';
$lang['SearchMembersPosts'] = 'Voir les messages de cet utilisateur';
$lang['CurrentPage'] = 'Page courante';
$lang['MemberGuestOnline'] = 'Dans les %d derni�res minutes, %d membre (%d cach�) et %d invit� ont visit� les forums.';
$lang['MembersGuestOnline'] = 'Dans les %d derni�res minutes, %d membres (%d cach�s) et %d invit� ont visit� les forums.';
$lang['MemberGuestsOnline'] = 'Dans les %d derni�res minutes, %d membre (%d cach�) et %d invit�s ont visit� les forums.';
$lang['MembersGuestsOnline'] = 'Dans les %d derni�res minutes, %d membres (%d cach�s) et %d invit�s ont visit� les forums.';
$lang['WhosOnline'] = 'Qui est en ligne';
$lang['Done'] = 'Fait';
$lang['KeywordsExplain'] = 'N\'importe quels mots-clef d\'au moins %d caract�res s�par�s par des espaces.';
$lang['BCCMyself'] = 'Envoyer une copie � ma propre adresse e-mail.';
$lang['Save'] = 'Sauvegarder';
$lang['Add'] = 'Ajouter';
$lang['MarkAllAsRead'] = 'Marquer tous les forums et discussions comme lus';
$lang['MarkAllAsReadDone'] = 'Tous les forums et discussions sont maintenant marqu�s comme lus.';
$lang['StringTooShort'] = '%s est trop court, au moins %d caract�res sont requis.';
$lang['StringTooLong'] = '%s est trop long, seuls %d caract�res sont autoris�s.';
$lang['Upload'] = 'Envoi';
$lang['RegistrationsDisabled'] = 'Inscriptions d�sactiv�es';
$lang['PostFormShortcut'] = 'Appuyer sur Alt+S (Cmd+S sur Apple) pour envoyer rapidement cela.';
$lang['EditThisMember'] = 'Modifier ce membre';
$lang['EmailTaken'] = 'L\'adresse e-mail %s est d�j� utilis�e sur ces forums. Veuillez en choisir une autre.';
$lang['RegisteredNotActivatedByAdmin'] = 'Votre compte %s est maintenant cr��. Avant de pouvoir vous identifier, l\'administrateur de ces forums doit activer votre compte. Veuillez attendre le temps qu\'il faut pour que cela soit fait.';
$lang['AdminActivationEmailBody'] = 'Bonjour,

Cet e-mail provient des forums [board_name]. Vous vous �tes inscrit en tant que [account_name]. L\'administrateur de ces forums doit encore activer votre compte. Quand cela sera fait, vous pourrez vous identifier en utilisant les informations suivantes :

Nom d\'utilisateur: [account_name]
Mot de passe: [password]

Si vous oubliez votre mot de passe, vous pouvez en demander un nouveau via le lien du formulaire d\'identification. Merci de vous �tre inscrit !

[board_name]
[board_link]
[admin_email]';
$lang['AdminActivationEmailSubject'] = 'Compte attendant activation';
$lang['NewEmailNotActivatedByAdmin'] = 'Votre profil a �t� modifi� avec succ�s. Du fait que vous avez chang� l\'adresse e-mail de votre compte %s, l\'administrateur de ces forums doit le r�activer. Vous serez d�connect� pendant ce temps.';
$lang['NewEmailAdminActivationEmailBody'] = 'Bonjour,

Cet e-mail provient des forums [board_name]. Vous avez chang� l\'adresse e-mail de votre compte [account_name], mais il n\'a pas encore �t� r�activ�. L\'administrateur doit en premier r�activer votre compte. Veuillez attendre le temps qu\'il faut pour que cela soit fait.

[board_name]
[board_link]
[admin_email]';
$lang['NewEmailAdminActivationEmailSubject'] = 'Compte attendant r�activation';
$lang['AdminActivatedAccountEmailBody'] = 'Bonjour,

Cet e-mail provient des forums [board_name]. L\'administrateur a activ� votre compte [account_name]. Vous pouvez maintenant vous identifier.

[board_name]
[board_link]
[admin_email]';
$lang['AdminActivatedAccountEmailSubject'] = 'Compte activ�';

?>

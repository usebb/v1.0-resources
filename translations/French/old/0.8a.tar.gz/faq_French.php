<?php

/*
	Copyright (C) 2003-2006 UseBB Team
	http://www.usebb.net
	
	$Header: /cvsroot/usebb/UseBB/languages/faq_English.php,v 1.7 2006/01/07 14:02:27 pc_freak Exp $
	
	This file is part of UseBB.
	
	UseBB is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 2 of the License, or
	(at your option) any later version.
	
	UseBB is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.
	
	You should have received a copy of the GNU General Public License
	along with UseBB; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/*
	Author : kiplantt
	E-mail : kiplantt@yahoo.fr
	Date : 15/03/2006
	UseBB version : 0.8a
*/

//
// Die when called directly in browser
//
if ( !defined('INCLUDED') )
	exit();

//
// Initialize a new faq holder array
//
$faq = array();

//
// Define headings and questions
//

$faq[] = array('--', 'Comptes utilisateurs');
$faq[] = array('Suis-je oblig� de m\'inscrire ?', 'L\'inscription peut �tre requise pour �crire dans certains forums, cela d�pend si l\'�criture pour les invit�s est activ�e ou pas (cela peut diff�rer d\'un forum � l\'autre). G�n�ralement, l\'inscription est une bonne id�e car elle apporte beaucoup de fonctions suppl�ementaires.');
$faq[] = array('Quels sont les avantages de l\'inscription ?', 'Tout d\'abord, vous b�n�ficiez d\'un compte personnel avec votre nom qui ne sera disponible que pour vous. Vous aurez aussi un profil personnel o� vous pouvez donner des informations suppl�mentaires � propos de vous et vous pouvez ajuster les forums � va go�ts via la fonction "Modifier les pr�f�rences", qui peut aussi inclure une option de choix de langue et de template. Une fonction tr�s int�ressante est la possibilit� de s\'abonner aux discussions.');
$faq[] = array('De quoi ai-je besoin pour m\'inscrire ?', 'Pour s\'inscrire, vous devez choisir un pseudonyme (nom d\'utilisateur) qui sera la clef de votre compte. Si vous le voulez, vous pouvez aussi utiliser votre vrai nom � la place d\'un pseudonyme. Notez que vous ne pourrez plus modifier par vous m�me votre nom d\'utilisateur apr�s inscription, bien que le nom affich� peut �tre modifi� n\'importe quand pendant que le nom d\'utilisateur reste le m�me. Vous avez aussi besoin d\'une adresse e-mail valide (qui peut �tre requise pour activer votre compte) et d\'un mot de passe (qui peut �tre modifi� par la suite).');
$faq[] = array('Je n\'ai pas re�u l\'e-mail d\'activation !', 'Vous devriez quand m�me pouvoir vous connecter sans �tre activ�. Sinon, demandez un nouveau mot de passe. Si cela ne fonctionne pas, contactez l\'administrateur.');
$faq[] = array('Que faire si j\'oublie mon mot de passe ou que mon adresse e-mail ne fonctionne plus ?', 'Vous pouvez toujours demander un nouveau mot de passe via le lien sur la page d\'identification. Si votre adresse e-mail ne fonctionne plus ou que vous l\'avez oubli�e, contactez un administrateur. Il/elle pourra vous donner l\'adresse e-mail avec laquelle vous vous �tes inscris ou vous ajustera votre compte avec votre nouvelle adresse e-mail fonctionnelle.');
$faq[] = array('Que sont les mod�rateurs et administrateurs ?', 'Un mod�rateur est une personne qui v�rifie les messages inappropri�s sur un ou plusieurs forums. Il/elle peut aussi aider les utilisateurs. Un administrateur est un mod�rateur sur tous les forums. Il peut aussi assigner des mod�rateurs et modifier les pr�f�rences des forums.');
$faq[] = array('Comment puis-je devenir un mod�rateur ou un administrateur ?', 'Normallement, vous ne pouvez pas. Vous pouvez toujours essayer de demander � l\'administrateur si vous �tes int�ress�.');
$faq[] = array('Puis-je modifier mon rang ?', 'Non, seuls les administrateur peuvent vous donner un rang personnalis�.');

$faq[] = array('--', 'Abonnements');
$faq[] = array('Comment puis-je m\'abonner aux discussions ?', 'Au bas de chaque discussion, vous trouverez un lien pour vous y abonner. Vous pouvez seulement vous abonner si vous �tes identifi�.');
$faq[] = array('Comment puis-je me d�sabonner des discussions ?', 'Vous pouvez vous d�sabonner en cliquant sur le lien de d�sabonnement ou via la vue d\'ensemble des abonnements dans votre panel.');

$faq[] = array('--', 'Votre profil');
$faq[] = array('Comment puis-je modifier mon nom d\'utilisateur ?', 'Vous ne pouvez pas changer votre nom d\'utilisateur (nom d\'identification) par vous-m�me. Seuls les administrateurs peuvent le faire. Vous pouvez cependant changer votre nom affich� � tout moment.');
$faq[] = array('Quelle est la diff�rence entre nom d\'utilisateur, nom affich� et nom r�el ?', 'Votre nom d\'utilisateur, que vous utilisez pour vous identifier sur les forums, est constant, vous ne pouvez le modifier. Votre nom affich� (qui est � l\'inscription identique � votre nom d\'utilisateur) est le nom affich� publiquement. Vous pouvez toujours le changer mais notez que vous aurez toujours � vous identifier avec votre nom d\'utilisateur constant. Votre nom r�el, qui est optionnel, est seulement affich� sur la page de profil.');
$faq[] = array('Ma langue n\'est pas disponible dans le menu d�roulant !', 'Veuillez demander � l\'administrateur s\'il/elle ne veut pas ajouter une traduction pour votre langue.');
$faq[] = array('Pourquoi ne puis-je pas choisir un autre template ?', 'Problablement car il n\'y a aucun autre template disponible sur ces forums.');

$faq[] = array('--', 'Discussions et messages');
$faq[] = array('Que sont les discussions et les messages ?', 'Une discussion est un groupe de messages dans un forum. Si vous cliquez sur un forum de l\'index, une vue d\'ensemble des discussions de ce forum est affich�e.');
$faq[] = array('Que sont les discussions �pingl�es ?', 'Les discussions �pingl�es sont con�ues pour �tre toujours en haut de la vue d\'ensemble des discussions. G�n�ralement, les utilisateurs normaux ne peuvent pas cr�er de discussions �pingl�es, mais les mod�rateurs et administrateurs oui.');
$faq[] = array('Pourquoi ne puis-je pas �crire de nouvelles discussions ou r�ponses ?', 'Si aucun lien n\'appara�t pour cr�er de nouvelle discussions ou messages c\'est que vous n\'est pas autoris� � le faire. Cela peut soit �tre un param�tre du forum, soit la discussion a �t� ferm�e par un mod�rateur. En cas de doute, contactez l\'administrateur.');
$faq[] = array('Que sont les BBCodes et les �motic�nes ?', 'Les BBCodes sont des balises que vous pouvez utiliser pour ajouter certains �l�ments � vos messages. Essayez-en quelques unes et pr�visualisez votre message pour voir l\'effet. Les �motic�nes sont utilis�es pour exprimer des �motions dans vos messages.');
$faq[] = array('Mon compteur de messages n\'augmente pas !', 'Dans certains forums, le comptage des messages peut �tre d�sactiv�. Ceci est habituel pour les forums de test ou les forums g�n�raux de bavardage.');
$faq[] = array('Pourquoi dois-je attendre un certain temps entre les messages ?', 'La protection contre l\'inondation de messages (flood) est utilis�e pour pr�venir le pollupostage (spamming) ou l\'inondation (flooding) de requ�tes et de messages. Veuillez patienter un moment et renvoyer votre message plus tard.');

$faq[] = array('--', 'Divers');
$faq[] = array('Je ne re�ois aucun e-mail de ces forums !', 'L\'administrateur a peut-�tre d�sactiv� les e-mails d\'information ou l\'adresse e-mail de votre profil ne fonctionne plus.');
$faq[] = array('Qu\'est-ce qu\'un fil RSS ?', 'Les fils RSS sont utilis�s pour rassembler les informations r�centes de sites ou de forums dans un lecteur de news/RSS ou dans certains navigateurs.');
$faq[] = array('O�, dans mon profil, puis-je inscrire mon compte Google Talk ?', 'Google Talk est un r�seau de messagerie instantan�e utilisant le protocole Jabber/XMPP. Vous pouvez inscrire votre nom de compte (complet, en incluant le nom de domaine) dans le champ Jabber/XMPP de votre profil.');

$faq[] = array('--', '� propos de UseBB');
$faq[] = array('Qui a cr�� ce syst�me de forums ? Qu\'est-ce que c\'est UseBB ?', 'Ce syst�me de forums, appel� <em>UseBB</em>, est d�velopp� par la UseBB Team. UseBB est un logiciel Open Source distribu� sous la licence GPL. Vous pouvez t�l�charger UseBB grauitement depuis <a href="http://www.usebb.net">www.usebb.net</a>. N\'oubliez pas que les administrateurs des ces forums peuvent avoir ajout� des fonctionnalit�s additionnelles.');
$faq[] = array('Les cr�ateurs de UseBB sont-ils responsables pour ces forums ?', 'Non, ces forums sont maintenus par le(s) webmestre(s) de ce site. La UseBB Team ne peut �tre en aucun cas tenue pour responsable de ces forums.');
$faq[] = array('J\'ai une plainte � propos de ces forums. � qui dois-je m\'adresser ?', 'Si c\'est � propos du logiciel lui-m�me, pas du contenu, vous seriez le bienvenu de l\'indiquer � la <a href="http://www.usebb.net">UseBB Team</a>. Pour toute autre demande, veuillez contacter l\'administrateur de ces forums.');

?>

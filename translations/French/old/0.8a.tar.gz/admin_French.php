<?php

/*
	Copyright (C) 2003-2006 UseBB Team
	http://www.usebb.net
	
	$Header: /cvsroot/usebb/UseBB/languages/admin_English.php,v 1.53 2006/02/08 16:59:34 pc_freak Exp $
	
	This file is part of UseBB.
	
	UseBB is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 2 of the License, or
	(at your option) any later version.
	
	UseBB is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.
	
	You should have received a copy of the GNU General Public License
	along with UseBB; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

//
// Die when called directly in browser
//
if ( !defined('INCLUDED') )
	exit();

$lang['AdminLogin'] = 'Identification admin';
$lang['AdminPasswordExplain'] = 'Pour des raisons de s�curit�, vous devez entrer votre mot de passe pour vous identifier dans le panel d\'administration.';

$lang['RunningBadACPModule'] = 'UseBB ne peut pas lancer de module car un ou plusieurs aspects sont manquants (pas d\'objet $usebb_module trouv� et/ou m�thode d\'objet run_module() manquante).';

$lang['Category-main'] = 'G�n�ral';
$lang['Item-index'] = 'Index';
$lang['Item-version'] = 'V�rifier les mises � jour';
$lang['Item-config'] = 'Configuration g�n�rale';
$lang['Category-forums'] = 'Forums';
$lang['Item-categories'] = 'G�rer les cat�gories';
$lang['Item-forums'] = 'G�rer les forums';
$lang['Category-various'] = 'Divers';
$lang['Item-iplookup'] = 'Consultation d\'adresse IP';
$lang['Item-sqltoolbox'] = 'Utilitaire SQL';
$lang['Item-modules'] = 'Modules du panel d\'admin';
$lang['Category-members'] = 'Membres';
$lang['Item-members'] = 'G�rer les membres';
$lang['Item-delete_members'] = 'Supprimer des membres';
$lang['Item-register_members'] = 'Inscrire des membres';
$lang['Item-activate_members'] = 'Activer des membres';
$lang['Item-prune_forums'] = 'Nettoyer les forums';

$lang['IndexWelcome'] = 'Bienvenu dans le panel d\'administration de vos forums UseBB. Avec celui-ci, vous pouvez contr�ler tous les aspects de vos forums, modifier les pr�f�rences, g�rer les forums, les membres, etc.';
$lang['IndexSystemInfo'] = 'Informations syst�me';
$lang['IndexUseBBVersion'] = 'Version de UseBB';
$lang['IndexPHPVersion'] = 'Version de PHP';
$lang['IndexSQLServer'] = 'Pilote du serveur SQL';
$lang['IndexHTTPServer'] = 'Serveur HTTP';
$lang['IndexOS'] = 'Syst�me d\'exploitation';
$lang['IndexLinks'] = 'Liens';
$lang['IndexUnactiveMembers'] = 'Membres non-activ�s';
$lang['IndexNoUnactiveMembers'] = 'Il n\'y aucun membre qui attend l\'activation de l\'administrateur.';
$lang['IndexOneUnactiveMember'] = 'Il y a un membre qui attend l\'activation de l\'administrateur.';
$lang['IndexMoreUnactiveMembers'] = 'Il y a %d membres qui attendent l\'activation de l\'administrateur.';

$lang['VersionFailed'] = 'La derni�re version n\'a pas pu �tre d�termin�e (%s d�sactiv�). Veuillez visiter souvent %s pour �tre s�r que vous avez la derni�re version.';
$lang['VersionLatestVersionTitle'] = 'Forums � jour';
$lang['VersionLatestVersion'] = 'Ces forums sont propuls� par UseBB %s qui est la derni�re version stable disponible.';
$lang['VersionNeedUpdateTitle'] = 'Nouvelle version disponible!';
$lang['VersionNeedUpdate'] = 'Ces forums sont propuls�s par UseBB %s qui doit �tre mis � jour vers la version %s pour rester s�curis� et sans bogue! Veuillez visiter %s pour t�l�charger la derni�re version.';
$lang['VersionBewareDevVersionsTitle'] = 'Version de d�veloppement';
$lang['VersionBewareDevVersions'] = 'Ces forums sont propuls�s par UseBB %s. Cependant, UseBB %s reste la derni�re version stable disponible. Soyez conscient des probl�mes et incompatibilit�s qui peuvent exister avec les versions de d�veloppement.';

$lang['ConfigInfo'] = 'Sur cette page, vous pouvez modifier toutes les pr�f�rences de vos forums. Faites attention � la modification des param�tres de la base de donn�e. Les champs marqu�s par une ast�risque (*) sont requis.';
$lang['ConfigSet'] = 'Les nouvelles pr�f�rences ont �t� sauv�es. Cela sera visible au chargement d\'une nouvelle page.';
$lang['ConfigMissingFields'] = 'Certains champs �taient manquants ou incorrects (par ex. du texte quand un nombre �tait attendu). Veuillez v�rifier les champs suivants :';
$lang['ConfigBoard-type'] = 'Type';
$lang['ConfigBoard-server'] = 'Serveur';
$lang['ConfigBoard-username'] = 'Nom d\'utilisateur';
$lang['ConfigBoard-passwd'] = 'Mot de passe';
$lang['ConfigBoard-dbname'] = 'Base de donn�e';
$lang['ConfigBoard-prefix'] = 'Pr�fixe de table';
$lang['ConfigBoardSection-general'] = 'G�n�ral';
$lang['ConfigBoardSection-cookies'] = 'Cookies';
$lang['ConfigBoardSection-sessions'] = 'Sessions';
$lang['ConfigBoardSection-page_counts'] = '�l�ments par page';
$lang['ConfigBoardSection-date_time'] = 'Dates &amp; temps';
$lang['ConfigBoardSection-database'] = 'Base de donn�e';
$lang['ConfigBoardSection-advanced'] = 'Pr�f�rences avanc�es';
$lang['ConfigBoardSection-email'] = 'E-mail';
$lang['ConfigBoardSection-additional'] = 'Fonctions additionnelles';
$lang['ConfigBoardSection-user_rights'] = 'Droits d\'utilisateur';
$lang['ConfigBoardSection-layout'] = 'Apparence';
$lang['ConfigBoard-admin_email'] = 'Adresse e-mail de l\'administrateur';
$lang['ConfigBoard-board_descr'] = 'Description des forums';
$lang['ConfigBoard-board_keywords'] = 'Mots-clef des forums (s�par�s par des virgules)';
$lang['ConfigBoard-board_name'] = 'Nom des forums';
$lang['ConfigBoard-date_format'] = 'Format de date';
$lang['ConfigBoard-language'] = 'Langue par d�faut';
$lang['ConfigBoard-session_name'] = 'Nom de session';
$lang['ConfigBoard-template'] = 'Template par d�faut';
$lang['ConfigBoard-active_topics_count'] = 'Discussion actives';
$lang['ConfigBoard-avatars_force_width'] = 'Largeur d\'avatar forc�e (px)';
$lang['ConfigBoard-avatars_force_height'] = 'Hauteur d\'avatar forc�e (px)';
$lang['ConfigBoard-debug'] = 'Mode d�boguage';
$lang['ConfigBoard-email_view_level'] = 'Niveau  de vision des adresses e-mail';
$lang['ConfigBoard-flood_interval'] = 'Intervalle contre l\'inondation (flood)';
$lang['ConfigBoard-members_per_page'] = 'Membres par page';
$lang['ConfigBoard-online_min_updated'] = 'Utilisateurs en ligne pendant les derni�res minutes';
$lang['ConfigBoard-output_compression'] = 'Compression du rendu';
$lang['ConfigBoard-passwd_min_length'] = 'Longueur minimale des mots de passe';
$lang['ConfigBoard-posts_per_page'] = 'Messages per page';
$lang['ConfigBoard-rss_items_count'] = 'Nombres d\'�l�ments RSS';
$lang['ConfigBoard-search_limit_results'] = 'Limiter les recherches � x r�sultats';
$lang['ConfigBoard-search_nonindex_words_min_length'] = 'Longueur minimum des mots-clef';
$lang['ConfigBoard-session_max_lifetime'] = 'Temps de vie de session maximum (secondes)';
$lang['ConfigBoard-show_edited_message_timeout'] = 'Montrer que le message a �t� modifi� seulement si cela a �t� fait x secondes apr�s l\'envoi du message';
$lang['ConfigBoard-topicreview_posts'] = 'Nombres de messages pr�visualis�s';
$lang['ConfigBoard-topics_per_page'] = 'Discussions par page';
$lang['ConfigBoard-view_detailed_online_list_min_level'] = 'Niveau minimum pour visualiser la liste d�taill�e des membres en ligne';
$lang['ConfigBoard-view_forum_stats_box_min_level'] = 'Niveau minimum pour voir la bo�te de statistiques';
$lang['ConfigBoard-view_hidden_email_addresses_min_level'] = 'Niveau minimum pour voir les adresses e-mail cach�es';
$lang['ConfigBoard-view_memberlist_min_level'] = 'Niveau minimum pour voir la liste des membres';
$lang['ConfigBoard-view_stafflist_min_level'] = 'Niveau minimum pour voir la liste de l\'�quipe';
$lang['ConfigBoard-view_stats_min_level'] = 'Niveau minimum pour voir la page des statistiques';
$lang['ConfigBoard-view_contactadmin_min_level'] = 'Niveau minimum pour voir le lien de contact de l\'admin';
$lang['ConfigBoard-allow_multi_sess'] = 'Autoriser plusieurs sessions par IP';
$lang['ConfigBoard-board_closed'] = 'Fermer les forums';
$lang['ConfigBoard-cookie_secure'] = 'Cookies s�curis�s (pour HTTPS)';
$lang['ConfigBoard-dst'] = 'Heure d\'�t�';
$lang['ConfigBoard-enable_contactadmin'] = 'Activer le lien de contact de l\'admin';
$lang['ConfigBoard-enable_detailed_online_list'] = 'Activer la liste d�taill�e des membres en ligne';
$lang['ConfigBoard-enable_forum_stats_box'] = 'Activer la bo�te des statistiques du forum';
$lang['ConfigBoard-enable_memberlist'] = 'Activer la liste des membres';
$lang['ConfigBoard-enable_quickreply'] = 'Activer la r�ponse rapide';
$lang['ConfigBoard-enable_rss'] = 'Activer le fil RSS';
$lang['ConfigBoard-enable_stafflist'] = 'Activer la liste de l\'�quipe';
$lang['ConfigBoard-enable_stats'] = 'Activer la page des statistiques';
$lang['ConfigBoard-friendly_urls'] = 'Activer les adresses plaisantes';
$lang['ConfigBoard-friendly_urls-info'] = 'Requi�re Apache et mod_rewrite. Cela d�sactivera les URL d\'IDs de session.';
$lang['ConfigBoard-guests_can_access_board'] = 'Les invit�s peuvent acc�der aux forums';
$lang['ConfigBoard-guests_can_view_profiles'] = 'Les invit�s peuvent voir les profils des membres';
$lang['ConfigBoard-hide_avatars'] = 'Cacher tous les avatars';
$lang['ConfigBoard-hide_signatures'] = 'Cacher toutes les signatures';
$lang['ConfigBoard-hide_userinfo'] = 'Cacher les informations des utilisateurs';
$lang['ConfigBoard-rel_nofollow'] = 'Activer l\'attribut Google nofollow pour les liens BBCodes';
$lang['ConfigBoard-return_to_topic_after_posting'] = 'Retourner � la discussion apr�s l\'envoi d\'un message';
$lang['ConfigBoard-sig_allow_bbcode'] = 'Activer le BBCode dans les signatures';
$lang['ConfigBoard-sig_allow_smilies'] = 'Activer les �motic�nes dans les signatures';
$lang['ConfigBoard-sig_max_length'] = 'Longueur maximum des signatures';
$lang['ConfigBoard-single_forum_mode'] = 'Mode de forum unique (si disponible)';
$lang['ConfigBoard-target_blank'] = 'Les liens BBCode s\'ouvrent dans une nouvelle fen�tre';
$lang['ConfigBoard-activation_mode'] = 'Mode d\'activation';
$lang['ConfigBoard-activation_mode0'] = 'Pas d\'activation requise';
$lang['ConfigBoard-activation_mode1'] = 'Activation par e-mail';
$lang['ConfigBoard-activation_mode2'] = 'Activation par l\'administrateur';
$lang['ConfigBoard-board_closed_reason'] = 'Raison de fermeture des forums';
$lang['ConfigBoard-board_url'] = 'URL des forums (laisser vide pour d�tection automatique)';
$lang['ConfigBoard-cookie_domain'] = 'Domaine des cookies';
$lang['ConfigBoard-cookie_path'] = 'Chemin des cookies';
$lang['ConfigBoard-session_save_path'] = 'Chemin de sauvegarde des sessions';
$lang['ConfigBoard-exclude_forums_active_topics'] = 'Exclure les forums des discussions actives';
$lang['ConfigBoard-exclude_forums_rss'] = 'Exclure les forums du fil RSS';
$lang['ConfigBoard-exclude_forums_stats'] = 'Exclure les forums de la page des statistiques';
$lang['ConfigBoard-timezone'] = 'Fuseau horaire';
$lang['ConfigBoard-debug0'] = 'D�sactiv�';
$lang['ConfigBoard-debug1'] = 'Information de d�boguage simple';
$lang['ConfigBoard-debug2'] = 'Information de d�boguage  �tendue';
$lang['ConfigBoard-email_view_level0'] = 'Cacher toutes les adresses e-mail';
$lang['ConfigBoard-email_view_level1'] = 'Activer le formulaire d\'e-mail';
$lang['ConfigBoard-email_view_level2'] = 'Afficher avec protection anti-spam';
$lang['ConfigBoard-email_view_level3'] = 'Afficher tel quel';
$lang['ConfigBoard-output_compression0'] = 'D�sactiv�';
$lang['ConfigBoard-output_compression1'] = 'Compresser l\'HTML';
$lang['ConfigBoard-output_compression2'] = 'Activer Gzip';
$lang['ConfigBoard-output_compression3'] = 'Compresser l\'HTML + Gzip';
$lang['ConfigBoard-level0'] = 'Invit�s';
$lang['ConfigBoard-level1'] = 'Membres';
$lang['ConfigBoard-level2'] = 'Mod�rateurs';
$lang['ConfigBoard-level3'] = 'Administrateurs';
$lang['ConfigBoard-enable_acp_modules'] = 'Activer les modules du panel d\'admin';
$lang['ConfigBoard-disable_registrations'] = 'D�sactiver l\'inscription';
$lang['ConfigBoard-disable_registrations_reason'] = 'Raison de la d�sactivation de l\'inscription';
$lang['ConfigBoard-allow_duplicate_emails'] = 'Autoriser les adresses e-mail d�j� existantes';

$lang['CategoriesInfo'] = 'Cette section vous permet de g�rer les diff�rentes cat�gories de ces forums.';
$lang['CategoriesAddNewCat'] = 'Ajouter une nouvelle cat�gorie';
$lang['CategoriesAdjustSortIDs'] = 'Ajuster les IDs de tri';
$lang['CategoriesSortAutomatically'] = 'Trier les cat�gories automatiquement';
$lang['CategoriesNoCatsExist'] = 'Il n\'existe pour l\'instant aucune cat�gorie.';
$lang['CategoriesCatName'] = 'Nom de la cat�gorie';
$lang['CategoriesSortID'] = 'ID de tri';
$lang['CategoriesMissingFields'] = 'Certains champs requis �taient manquants. Veuillez les remplir correctement.';
$lang['CategoriesSortChangesApplied'] = 'Vos modifications des IDs de tri ont �t� appliqu�es.';
$lang['CategoriesConfirmCatDelete'] = 'Confirmation de la suppression de la cat�gorie';
$lang['CategoriesConfirmCatDeleteContent'] = '�tes-vous s�r que vous voulez supprimer la cat�gorie %s ? Cette action est irr�versible !';
$lang['CategoriesMoveContents'] = 'D�placer le contenu de la cat�gorie vers %s';
$lang['CategoriesDeleteContents'] = 'Supprimer le contenu';
$lang['CategoriesEditingCat'] = 'Modification de la cat�gorie %s';

$lang['ForumsInfo'] = 'Cette section vous permet de g�rer les diff�rents forums.';
$lang['ForumsAddNewForum'] = 'Ajouter un nouveau forum';
$lang['ForumsAdjustSortIDs'] = 'Ajuster les IDs de tri';
$lang['ForumsSortAutomatically'] = 'Trier les forums automatiquement';
$lang['ForumsNoForumsExist'] = 'Il n\'existe pour l\'instant aucun forum.';
$lang['ForumsForumName'] = 'Nom du forum';
$lang['ForumsCatName'] = 'Cat�gorie parente';
$lang['ForumsDescription'] = 'Description';
$lang['ForumsStatus'] = 'Statut';
$lang['ForumsStatusOpen'] = 'Ouvert';
$lang['ForumsAutoLock'] = 'Fermer automatiquement apr�s x r�ponses';
$lang['ForumsIncreasePostCount'] = 'Augmenter le compteur de message';
$lang['ForumsModerators'] = 'Mod�rateurs';
$lang['ForumsModeratorsExplain'] = 'Nom d\'utilisateur (pas les nom affich�s), s�par�s par des virgules. Non sensible � la casse.';
$lang['ForumsModeratorsUnknown'] = 'Membre(s) inconnu(s) : %s.';
$lang['ForumsHideModsList'] = 'Cacher la liste des mod�rateurs';
$lang['ForumsSortID'] = 'ID de tri';
$lang['ForumsMissingFields'] = 'Certains champs requis �taient manquants. Veuillez les remplir correctement.';
$lang['ForumsSortChangesApplied'] = 'Vos modifications des IDs de tri ont �t� appliqu�es.';
$lang['ForumsConfirmForumDelete'] = 'Confirmation de la suppression du forum';
$lang['ForumsConfirmForumDeleteContent'] = '�tes-vous s�r que vous voulez supprimer le forums %s ? Cette action est irr�versible !';
$lang['ForumsMoveContents'] = 'D�placer le contenu du forum vers %s';
$lang['ForumsMoveModerators'] = 'D�placer les mod�rateurs en m�me temps que le contenu.';
$lang['ForumsDeleteContents'] = 'Supprimer le contenu';
$lang['ForumsEditingForum'] = 'Modification du forum %s';
$lang['ForumsGeneral'] = 'Pr�f�rences g�n�rales';
$lang['ForumsAuth'] = 'Droits';
$lang['ForumsAuthNote'] = 'Les pr�f�rences ne s\'h�ritent pas !';
$lang['Forums-level0'] = 'Invit�s';
$lang['Forums-level1'] = 'Membres';
$lang['Forums-level2'] = 'Mod�rateurs';
$lang['Forums-level3'] = 'Administrateurs';
$lang['Forums-auth0'] = 'Voir le forum';
$lang['Forums-auth1'] = 'Lire les discussions';
$lang['Forums-auth2'] = 'Cr�er de nouvelles discussions';
$lang['Forums-auth3'] = 'R�pondre aux discussions';
$lang['Forums-auth4'] = 'Modifier les messages des autres';
$lang['Forums-auth5'] = 'D�placer les discussion';
$lang['Forums-auth6'] = 'Supprimer les discussions et messages';
$lang['Forums-auth7'] = 'Fermer les discussions';
$lang['Forums-auth8'] = '�pingler les discussions';
$lang['Forums-auth9'] = 'Utiliser HTML (dangereux)';

$lang['IPLookupSearchHostname'] = 'Rechercher les adresses Internet';
$lang['IPLookupSearchUsernames'] = 'Rechercher les noms d\'utilisateur';
$lang['IPLookupResult'] = 'L\'adresse Internet correspondant � l\'adresse IP %s est %s.';
$lang['IPLookupNotFound'] = 'Aucune adresse Internet correspondant � %s n\'a �t� trouv�e.';
$lang['IPLookupUsernamesSingular'] = 'Le nom d\'utilisateur %s a �t� utilis� par %s pour �crire des messages.';
$lang['IPLookupUsernamesPlural'] = 'Les %d noms d\'utilisateur %s ont �t� utilis�s par %s pour �crire des messages.';
$lang['IPLookupUsernamesNotFound'] = 'Aucun nom d\'utilisateur correspondant � %s n\'a �t� trouv�.';

$lang['SQLToolboxWarningTitle'] = 'Avertissement important !';
$lang['SQLToolboxWarningContent'] = 'Faites tr�s attention en utilisant l\'utilitaire de requ�te. L\'utilisation de ALTER, DELETE, TRUNCATE ou tout autre type de requ�te peu causer des dommages irr�versibles � vos forums ! Utilisez uniquement ceci si vous savez ce que vous faisez.';
$lang['SQLToolboxExecuteQuery'] = '�xecution d\'une requ�te';
$lang['SQLToolboxExecuteQueryInfo'] = 'Veuillez entrer une requ�te SQL � ex�cuter. Les r�sultats, s\'il y en a, appara�tront dans une seconde bo�te.';
$lang['SQLToolboxExecute'] = 'Ex�cuter';
$lang['SQLToolboxExecutedSuccessfully'] = 'Requ�te ex�cut�e avec succ�s.';
$lang['SQLToolboxMaintenance'] = 'Maintenance';
$lang['SQLToolboxMaintenanceInfo'] = 'Ces fonctions optimisent (et r�parent) les tables SQL utilis�es par UseBB. Il est conseill� pour les gros forums d\'optimiser souvent les tables.';
$lang['SQLToolboxRepairTables'] = 'R�parer les tables';
$lang['SQLToolboxOptimizeTables'] = 'Optimiser les tables';
$lang['SQLToolboxMaintenanceNote'] = 'Note: cela ne r�staure aucun donn�e perdue de la base de donn�e.';

$lang['ModulesInfo'] = 'Les modules du panel d\'administration vous donnent la possibilit� d\'�tendre ce panel avec vos propres fonctions ou avec des fonctions cr��es par d\'autres programmeurs. Des modules peuvent �tre trouv�s via le site Web UseBB : %s.';
$lang['ModulesLongName'] = 'Nom long';
$lang['ModulesShortName'] = 'Nom court';
$lang['ModulesCategory'] = 'Cat�gorie';
$lang['ModulesFilename'] = 'Nom du fichier';
$lang['ModulesDeleteNotPermitted'] = 'Pas permis';
$lang['ModulesDisabled'] = 'Les modules du panel d\'admin ont �t� d�sactiv�s dans les pr�f�rences de ces forums.';
$lang['ModulesNoneAvailable'] = 'Aucun module n\'est disponible.';
$lang['ModulesUpload'] = 'Charger un module';
$lang['ModulesUploadInfo'] = 'Veuillez entrer le nom d\'un fichier local d\'un module pour le charger.';
$lang['ModulesUploadDuplicateModule'] = 'Un module sous le nom %s existe d�j�. Veuillez d\'abord le supprimer.';
$lang['ModulesUploadNoValidModule'] = 'Le fichier %s n\'est pas un module UseBB valide.';
$lang['ModulesUploadFailed'] = 'La module %s n\'a pas pu �tre install�. La copie a �chou�.';
$lang['ModulesUploadDisabled'] = 'Le dossier des modules n\'est pas inscriptible. Le chargement a �t� d�sactiv�. Pour l\'activer, faites en sorte que le dossier %s soit inscriptible par le serveur (essayez chmod 777).';
$lang['ModulesConfirmModuleDelete'] = 'Confirmation de la suppression du module';
$lang['ModulesConfirmModuleDeleteInfo'] = '�tes-vous s�r que vous voulez supprimer le module %s (%s) ?';

$lang['MembersSearchMember'] = 'Recherche';
$lang['MembersSearchMemberInfo'] = 'Veuillez entrer un nom d\'utilisateur ou un nom affich� � modifier (ou seulement une partie).';
$lang['MembersSearchMemberExplain'] = 'Nom d\'utilisateur ou nom affich�';
$lang['MembersSearchMemberNotFound'] = 'Aucun membre avec le nom d\'utilisateur ou nom affich� %s n\'a �t� trouv�.';
$lang['MembersSearchMemberList'] = 'Les membres suivants ont �t� trouv�s';
$lang['MembersEditingMember'] = 'Modification du membre %s';
$lang['MembersEditingMemberInfo'] = 'Veuillez mettre � jour les informations de l\'utilisateur et envoyer le formulaire. Les champs marqu�s d\'une ast�risque (*) sont requis.';
$lang['MembersEditingMemberUsernameExists'] = 'Le nom d\'utilisateur %s existe d�j� en tant que nom d\'utilisateur ou nom affich�.';
$lang['MembersEditingMemberDisplayedNameExists'] = 'Le nom affich� %s existe d�j� en tant que nom d\'utilisateur ou nom affich�.';
$lang['MembersEditingMemberBanned'] = 'Bannis';
$lang['MembersEditingMemberBannedReason'] = 'Raison du bannissement';
$lang['MembersEditingMemberCantChangeOwnLevel'] = 'Vous ne pouvez pas changer votre propre niveau.';
$lang['MembersEditingMemberCantBanSelf'] = 'Vous ne pouvez pas vous bannir.';
$lang['MembersEditingComplete'] = 'Le profil du membre %s a �t� modifi� avec succ�s.';

$lang['DeleteMembersSearchMember'] = 'Recherche';
$lang['DeleteMembersSearchMemberInfo'] = 'Veuillez entrer un nom d\'utilisateur ou un nom affich� � suppimer (ou seulement une partie).';
$lang['DeleteMembersSearchMemberExplain'] = 'Nom d\'utilisateur ou nom affich�';
$lang['DeleteMembersSearchMemberNotFound'] = 'Aucun membre avec le nom d\'utilisateur ou nom affich� %s n\'a �t� trouv�.';
$lang['DeleteMembersSearchMemberList'] = 'Les membres suivants ont �t� trouv�s';
$lang['DeleteMembersConfirmMemberDelete'] = 'Confirmation de la suppression du membre';
$lang['DeleteMembersConfirmMemberDeleteContent'] = '�tes-vous s�r que vous voulez supprimer le membre %s ? Ceci est irr�versible !';
$lang['DeleteMembersComplete'] = 'Suppression du membre %s termin�e.';

$lang['RegisterMembersExplain'] = 'Ici, vous pouvez pr�inscrire des comptes. Veuillez simplement remplir les informations suivante pour cr�er un compte.';
$lang['RegisterMembersComplete'] = 'Inscription de l\'utilisateur %s termin�e. L\'utilisateur peut maintenant se connecter.';

$lang['ActivateMembersExplain'] = 'Ceci est la liste des membres qui ne sont pas encore activ�s. Ici, vous pouvez approuver manuellement des comptes. Une ast�risque (*) indique que le compte a d�j� �t� activ� auparavant.';
$lang['ActivateMembersNoMembers'] = 'Aucun membre � afficher.';
$lang['ActivateMembersListAdmin'] = 'Activation par l\'administrateur';
$lang['ActivateMembersListEmail'] = 'Activation par e-mail';
$lang['ActivateMembersListAll'] = 'Tout';

$lang['PruneForumsStart'] = 'Nettoyer';
$lang['PruneForumsExplain'] = 'En nettoyant les forums, vous pouvez supprimer ou d�placer les vieilles discussions et ainsi garder vos forums propres.';
$lang['PruneForumsForums'] = 'Forums � nettoyer';
$lang['PruneForumsAction'] = 'Action';
$lang['PruneForumsActionMove'] = 'D�placerer les discussions';
$lang['PruneForumsActionDelete'] = 'Supprimer les discussions';
$lang['PruneForumsMoveTo'] = 'D�placer les discussions vers';
$lang['PruneForumsTopicAge'] = '�ge des discussions';
$lang['PruneForumsTopicAgeField'] = 'Derni�re r�ponse vieille de %s jours.';
$lang['PruneForumsMoveToForumSelectedForPruning'] = 'Le forum vers lequel d�placer les discussions ne peut pas �tre s�lectionn� pour le nettoyage.';
$lang['PruneForumsConfirm'] = 'Confirmation';
$lang['PruneForumsConfirmText'] = 'Je comprends que cette action est irr�versible.';
$lang['PruneForumsNotConfirmed'] = 'Vous devez confirmer cette action.';
$lang['PruneForumsDone'] = 'Nettoyage termin�. %d discussions ont �t� nettoy�es.';
$lang['PruneForumsExcludeStickies'] = 'Exclure les discussions �pingl�es';

?>

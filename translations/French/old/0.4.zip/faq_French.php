<?php

/*
	Copyright (C) 2003-2005 UseBB Team
	http://www.usebb.net
	
	$Header: /cvsroot/usebb/UseBB/languages/faq_English.php,v 1.2 2005/02/09 12:42:40 pc_freak Exp $
	
	This file is part of UseBB.
	
	UseBB is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 2 of the License, or
	(at your option) any later version.
	
	UseBB is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.
	
	You should have received a copy of the GNU General Public License
	along with UseBB; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/*
	Author : Teg
	email : teg@deleplanque.net
	Date : 05/04/2005
	UseBB version : 0.4
*/

//
// Die when called directly in browser
//
if ( !defined('INCLUDED') )
	exit();

//
// Initialize a new faq holder array
//
$faq = array();

//
// Define headings and questions
//

$faq[] = array('--', 'Comptes des utilisateurs');
$faq[] = array('Dois-je m\'enregistrer?', 'L\'enregistrement est probablement requis pour pouvoir poster sur ce forum. Cela d�pend si l\'administrateur a activ� ou non la capacit� pour les invit�s de poster (cela peut d�pendre d\'un forum � l\'autre. G�n�ralement, s\'enregistrer est une bonne id�e puisque cela donne acc�s � de nombreuses fonctions suppl�mentaires.');
$faq[] = array('Quels sont les avantages de s\'enregistrer?', 'Avant tout, vous obtenez un compte personnel avec votre pseudonyme, qui vous sera alors r�serv�. Vous aurez �galement acc�s � un profil, o� vous pourrez saisir des informations suppl�mentaires � votre sujet si vous le souhaitez et vous pourrez configurer le forum � votre go�t via les menus "<i>Editer vos options</i>", ce qui inclus le changement d\'apparence et de langue.');
$faq[] = array('De quoi ai-je besoin pour m\'enregistrer?', 'Il faut choisir un pseudonyme (Nom d\'utilisateur) qui sera la clef de votre compte. Vous pouvez �galement utiliser votre vrai nom si vous le souhaitez. Note: vous ne pouvez pas changer votre nom d\'utilisateur vous-m�me apr�s enregistrement. Vous avez �galement besoin d\'une adresse email valide, et choisir un mot de passe, que vous pourrez changer par la suite.');
$faq[] = array('Que se passe-t-il si j\'oublie mon mot de passe ou si mon adresse email ne marche plus?', 'Vous pouvez toujours demander un nouveau mot de passe via le formulaire de connexion. Si vous adresse email ne fonctionne plus, contactez un administrateur. Il sera � m�me d\'ajuster votre profil avec votre nouvelle adresse.');

$faq[] = array('--', 'Questions sur UseBB');
$faq[] = array('Qui a fait ce forum?', 'Ce forum, appel� <em>UseBB</em>, est d�velopp� par la UseBB Team. UseBB est un logiciel libre publi� sous la licence GPL. Vous pouvez t�l�charger gratuitement UseBB depuis <a href="http://www.usebb.net">www.usebb.net</a>. Note: les administrateurs de ce site/forum y ont peut-�tre ajout� des fonctionnalit�s.');
$faq[] = array('J\'ai une plainte au sujet de ce forum. A qui dois-je l\'adresser.?', 'Si votre plainte concerne le forum lui-m�me, et non son contenu, vous �tes le bienvenu pour <a href="http://www.usebb.net">en parler � la UseBB Team</a>. Pour toute autre information, veuillez contacter les administrateurs de ce site/forum.');

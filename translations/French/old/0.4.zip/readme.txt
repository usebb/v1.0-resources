French language pack for UseBB version 0.4

==============
|Installation|
==============

Step 1:

	Unzip the the files faq_French.php and lang_French.php to the 'languages' directory.



Step 2:

	Open 'config.php' found in the UseBB installation folder.



Step 3:

	Find the line : ( around line 57 )

	$conf['available_languages'] = array('English', 'Deutsch', 'Nederlands');

	and change it to :

	$conf['available_languages'] = array('English', 'Deutsch', 'Nederlands', 'French');



Step 4: (optional)

	If you need the default language for your board to be French,

	find the line : ( around line 57 )

	$conf['language'] = 'English';

	and change it to :

	$conf['language'] = 'French';



That's all folks.



=======
|Notes|
=======

If you notice any mistakes I'll be glad to fix them.

Teg (teg@deleplanque.net)
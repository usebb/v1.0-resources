<?php

/*
	Copyright (C) 2003-2005 UseBB Team
	http://www.usebb.net
	
	$Header: /cvsroot/usebb/UseBB/languages/lang_English.php,v 1.43 2005/03/26 13:37:48 pc_freak Exp $
	
	This file is part of UseBB.
	
	UseBB is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 2 of the License, or
	(at your option) any later version.
	
	UseBB is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.
	
	You should have received a copy of the GNU General Public License
	along with UseBB; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/*
	Author : Teg
	email : teg@deleplanque.net
	Date : 05/04/2005
	UseBB version : 0.4
*/


//
// Die when called directly in browser
//
if ( !defined('INCLUDED') )
	exit();

//
// Initialize a new translations holder array
//
$lang = array();

//
// Translation settings
// Uncomment and change when necessary for translations
//
#$lang['character_encoding'] = 'iso-8859-1';
#$lang['language_code'] = 'fr';
#$lang['text_direction'] = 'ltr';

//
// Define translations
//
$lang['Home'] = 'Accueil';
$lang['YourPanel'] = 'Vos contr�les';
$lang['Register'] = 'S\'enregistrer';
$lang['FAQ'] = 'FAQ';
$lang['Search'] = 'Rechercher';
$lang['ActiveTopics'] = 'Sujets actifs';
$lang['LogIn'] = 'Connexion';
$lang['LogOut'] = 'D�connexion (%s)';
$lang['MemberList'] = 'Liste des membres';
$lang['StaffList'] = 'Membres du staff';
$lang['Statistics'] = 'Statistiques';
$lang['ContactAdmin'] = 'Contacter l\'administrateur';
$lang['Forum'] = 'Forum';
$lang['Topics'] = 'Sujets';
$lang['Posts'] = 'Messages';
$lang['LatestPost'] = 'Dernier message';
$lang['RSSFeed'] = 'Alimentation RSS';
$lang['NewPosts'] = 'Nouveaux messages';
$lang['NoNewPosts'] = 'Pas de nouveaux messages';
$lang['LockedNewPosts'] = 'Ferm� (nouveaux messages)';
$lang['LockedNoNewPosts'] = 'Ferm� (pas de nouveaux messages)';
$lang['Locked'] = 'Ferm�';
$lang['LastLogin'] = 'Derni�re connexion';
$lang['VariousInfo'] = 'Informations vari�es';
$lang['IndexStats'] = 'Ce forum regroupe %d messages dans %d sujets post�s par %d membres.';
$lang['NewestMember'] = 'Bienvenue � notre dernier membre: %s.';
$lang['OnlineUsers'] = 'Il y a eu %d membre(s) et %d invit�(s) en ligne durant les derni�res %d minutes.';
$lang['Username'] = 'Pseudo';
$lang['CurrentPassword'] = 'Mot de passe actuel';
$lang['UserID'] = 'ID utilisateur';
$lang['NoSuchForum'] = 'Ce forum %s n\'existe pas ou plus!';
$lang['WrongPassword'] = 'D�sol�, le mot de passe est incorrect. Demandez un nouveau mot de passe via le formulaire de connexion si vous ne vous en souvenez plus.';
$lang['Reset'] = 'Annuler';
$lang['SendPassword'] = 'Envoyer un nouveau mot de passe';
$lang['RegisterNewAccount'] = 'Enregistrer un nouveau compte';
$lang['RememberMe'] = 'Se souvenir de moi';
$lang['Yes'] = 'Oui';
$lang['No'] = 'Non';
$lang['NotActivated'] = 'Votre compte %s n\'est pas encore activ�. Veuillez consulter votre bo�te aux lettres pour obtenir les informations d\'activation.';
$lang['Error'] = 'Erreur';
$lang['Profile'] = 'Profil de %s';
$lang['Level'] = 'Niveau';
$lang['Administrator'] = 'Administrateur';
$lang['Moderator'] = 'Moderateur';
$lang['Registered'] = 'Enregistr�';
$lang['Email'] = 'Adresse email';
$lang['ContactInfo'] = 'Contacts';
$lang['Password'] = 'Mot de passe';
$lang['PasswordAgain'] = 'Mot de passe (encore)';
$lang['EverythingRequired'] = 'Tous les champs sont requis!';
$lang['UserAlreadyExists'] = 'D�sol�, l\'utilisateur %s existe d�j� sur ces forums. S\'il s\'agit de votre compte, enregistrez-vous ou demandez un nouveau mot de passe. Sinon, veuillez choisir un autre pseudo.';
$lang['RegisteredNotActivated'] = 'Votre compte (%s) a bien �t� cr��. Un email a �t� envoy� � %s avec les instructions n�cessaires pour l\'activer. Vous ne pouvez pas vous connecter tant que l\'activation n\'a pas �t� effectu�e.';
$lang['RegisteredActivated'] = 'Votre compte (%s) a bien �t� cr��. Un email a �t� envoy� � %s avec un r�sum� de vos informations. Vous pouvez d�s � pr�sent vous connecter.';
$lang['Never'] = 'Jamais';
$lang['Member'] = 'Membre';
$lang['RegistrationActivationEmailBody'] = 'Bonjour,

Ceci est un message automatique en provenance de/du [board_name]. Vous venez d\'enregistrer le compte [account_name], mais il n\est pas encore activ�. Veuillez clicker le lien suivant pour activer votre compte:

[activate_link]

ou copiez/collez le dans votre navigateur. Vous pourrez alors vous connecter en utilisant votre identifiant et mot de passe.

Identifiant: [account_name]
Mot de passe: [password]

Si vous oubliez votre mot de passe, vous pouvez en demander un nouveau via le formulaire de la page de connexion. Merci de vous �tre enregistr�!

[board_name]
[board_link]
[admin_email]';
$lang['SendpwdActivationEmailSubject'] = 'Nouveau mot de passe';
$lang['NoForums'] = 'Le forum est vide. L\'administrateur n\'a encore cr�� aucune cat�gorie.';
$lang['AlreadyActivated'] = 'Le compte correspondant � l\'ID a d�j� �t� activ�.';
$lang['Activate'] = 'Activer';
$lang['Activated'] = 'Votre compte a bien �t� (r�)activ�. Vous pouvez vous connecter avec le mot de passe contenu dans l\'email que vous avez re�u.';
$lang['WrongActivationKey'] = 'Le compte correspondant � l\'ID %d n\'a pas pu �tre activ�. La clef d\'activation est incorrecte. Etes-vous s�r de ne pas avoir demand� un nouveau mot de passe entre-temps?';
$lang['RegisterIt'] = 'Vous pouvez le cr�er via le lien <i>S\'enregistrer</i>.';
$lang['BoardClosed'] = 'Forum ferm�';
$lang['SendpwdActivationEmailBody'] = 'Bonjour,

Ceci est un message automatique en provenance de/du [board_name]. Vous avez demand� un nouveau mot de passe pour le compte [account_name]. Veuillez clicker le lien suivant pour activer votre compte:

[activate_link]

ou copiez/collez le dans votre navigateur. Vous pourrez alors vous connecter en utilisant votre identifiant et mot de passe:

Identifiant: [account_name]
Mot de passe: [password]

Si vous oubliez votre mot de passe, vous pouvez en demander un nouveau via le formulaire de la page de connexion. Merci de vous �tre enregistr�!

[board_name]
[board_link]
[admin_email]';
$lang['SendpwdEmailBody'] = 'Bonjour,

Ceci est un message automatique en provenance de/du [board_name]. Vous avez demand� un nouveau mot de passe pour le compte [account_name]. Vous pouvez vous connecter en utilisant votre identifiant et mot de passe:

Identifiant: [account_name]
Mot de passe: [password]

Si vous oubliez votre mot de passe, vous pouvez en demander un nouveau via le formulaire de la page de connexion. Merci de vous �tre enregistr�!

[board_name]
[board_link]
[admin_email]';
$lang['SendpwdEmailSubject'] = 'Nouveau mot de passe';
$lang['SendpwdActivated'] = 'Le nouveau mot de passe pour le compte %s a �t� envoy� � %s. Vous pouvez vous connecter avec votre nouveau mot de passe.';
$lang['SendpwdNotActivated'] = 'Le nouveau mot de passe pour le compte %s a �t� envoy� � %s. Il est accompagn� des informations n�cessaires pour r�activer ce compte.';
$lang['ForumIndex'] = 'Index du forum';
$lang['MissingFields'] = 'Les champs suivants sont manquants ou incorrects: %s.';
$lang['TermsOfUseContent'] = 'Vous approuvez que tous les messages de ce forum sont le reflet des opinions de leurs auteurs et non du webmaster, de l\'administrateur ou des mod�rateurs, sauf dans le cas de message �crits par eux.

Vous vous engagez � ne pas poster de contenu ill�gal, offensant ou obsc�ne sur ce forum. Dans le cas contraire, vous pouvez �tre banni, et votre FAI pourra �tre pr�venu de votre comportement. Pour ce faire, votre adresse IP est associ�e � chaque message que vous postez. Vous acceptez �galement que vos messages puissent �tre supprim�s, �dit�s, d�plac�s ou ferm�s par les administrateurs ou mod�rateurs s\'ils l\'estiment n�cessaire.

Toutes les informations que vous postez sur ce forum son conserv�es dans une base de donn�es. Ces informations ne seront pas redistribu�es par l\'administrateur sans votre permission. Cependant, ni le webmaster, ni l\'administrateur, ni les mod�rateurs, ni l\'�quipe de UseBB ne pourra �tre tenu responsable de la fuite des informations dans le cas d\'un piratage.

Ce forum utilise des cookies pour enregistrer des informations temporaires, n�cessaires au syst�me, sur votre ordinateur. Un cookie peut �galement contenir votre ID utilisateur et votre mot de passe crypt� pour permettre l\'identification automatique lorsque vous activez cette option. Si vous ne voulez pas que des cookies soient enregistr�s sur votre ordinateur, r�f�rez vous au manuel de votre navigateur pour savoir comment les bloquer.

En appuyant sur le bouton "J\'accepte", vous acceptez ces conditions d\'utilisation.';
$lang['TermsOfUse'] = 'Conditions d\'utilisation';
$lang['RegistrationActivationEmailSubject'] = 'Activation de compte';
$lang['NeedToBeLoggedIn'] = 'Vous devez �tre connect� pour effectuer cette action. Clickez sur le lien <i>Connexion</i> pour vous connecter ou <i>S\'enregistrer</i> pour cr�er un nouveau compte.';
$lang['WrongEmail'] = 'D�sol�, mais l\'adresse %s n\'est pas celle associ�e au compte %s. Si vous avez oubli� votre adresse email, voyez contacter un administrateur.';
$lang['Topic'] = 'Sujet';
$lang['Author'] = 'Auteur';
$lang['Replies'] = 'R�ponses';
$lang['Views'] = 'Vues';
$lang['Note'] = 'Note';
$lang['Hidden'] = 'Cach�(e)';
$lang['ACP'] = 'Panneau d\'administration';
$lang['SendMessage'] = 'Envoyer un message';
$lang['NoViewableForums'] = 'Votre niveau d\'utilisateur ne vous permet pas de voir les forums. Connectez-vous si ce n\'est pas encore fait. Si vous �tes connect�, vous ne devriez probablement pas �tre l�...';
$lang['Rank'] = 'Rank';
$lang['Location'] = 'Localisation';
$lang['Website'] = 'Site web';
$lang['Occupation'] = 'Occupation';
$lang['Interests'] = 'Int�r�ts';
$lang['MSNM'] = 'MSN Messenger';
$lang['YahooM'] = 'Yahoo Messenger';
$lang['AIM'] = 'AIM';
$lang['ICQ'] = 'ICQ';
$lang['Jabber'] = 'Jabber';
$lang['BannedIP'] = 'Votre adresse IP est bannie de ce forum.';
$lang['Avatar'] = 'Avatar';
$lang['AvatarURL'] = 'Adresse de l\'avatar';
$lang['BannedUser'] = 'Utilisateur banni';
$lang['BannedUserExplain'] = 'Votre compte a �t� banni de ce forum. Raison:';
$lang['BannedUsername'] = 'Le pseudo %s a �t� interdit sur ce forum. Veuillez en choisir un autre.';
$lang['BannedEmail'] = 'L\'adresse email %s a �t� interdite sur ce forum. Veuillez en choisir une autre.';
$lang['PostsPerDay'] = 'Messages par jour';
$lang['BoardClosedOnlyAdmins'] = 'Seuls les administrateurs peuvent se connecter lorsque le forum est ferm�.';
$lang['NoPosts'] = 'Pas de messages';
$lang['NoActivetopics'] = 'Pas de sujet actif sur ce forum pour le moment.';
$lang['AuthorDate'] = 'par %s le %s';
$lang['ByAuthor'] = 'Par: %s';
$lang['OnDate'] = 'Le: %s';
$lang['Re'] = 'Re:';
$lang['MailForm'] = 'Envoyer un email � %s';
$lang['SendEmail'] = 'Envoyer un message � %s';
$lang['NoMails'] = 'L\'utilisateur a choisi de ne pas recevoir d\'emails.';
$lang['UserEmailBody'] = 'Bonjour,

Ceci est un message automatique en provenance de/du [board_name]. L\'utilisateur [username] vous a envoy� ce message via notre forum.

[board_name]
[board_link]
[admin_email]

-----

[body]';
$lang['EmailSent'] = 'Votre email a �t� envoy� avec succ�s!';
$lang['To'] = 'A';
$lang['From'] = 'De';
$lang['Subject'] = 'Sujet';
$lang['Body'] = 'Message';
$lang['Send'] = 'Envoyer';
$lang['EditProfile'] = 'Editer le profil';
$lang['EditOptions'] = 'Editer les options';
$lang['EditPasswd'] = 'Changer de mot de passe';
$lang['PanelHome'] = 'Index du panneau';
$lang['NewEmailNotActivated'] = 'Votre profil a bien �t� mis � jour. Puisque vous avez chang� d\'adresse email, vous devez r�activer votre compte. Un email a �t� envoy� � %s avec les instructions n�cessaires. Vous serez d�connect� en attendant la r�activation.';
$lang['Required'] = 'Requis';
$lang['ViewProfile'] = 'Voir le profil';
$lang['NewEmailActivationEmailBody'] = 'Bonjour,

Ceci est un message automatique en provenance de/du [board_name]. Vous venez de changer l\'adresse email associ�e au compte [account_name], qui n\'a pas encore �t� r�activ�. Pour ce faire, veuillez clicker sur le lien suivant:

[activate_link]

ou copiez/collez le dans votre navigateur. Vous pourrez alors vous connecter en utilisant votre identifiant et mot de passe:

Identifiant: [account_name]
Mot de passe: [password]

Si vous oubliez votre mot de passe, vous pouvez en demander un nouveau via le formulaire de la page de connexion.

[board_name]
[board_link]
[admin_email]';
$lang['NewEmailActivationEmailSubject'] = 'R�activation de compte';
$lang['Signature'] = 'Signature';
$lang['SessionInfo'] = 'Infos sur la session';
$lang['SessionID'] = 'ID de la session';
$lang['IPAddress'] = 'Addresse IP';
$lang['Seconds'] = 'Secondes';
$lang['Updated'] = 'Mis � jour';
$lang['Pages'] = 'Pages';
$lang['AutoLogin'] = 'Connexion automatique';
$lang['Enabled'] = 'Activ�(e)';
$lang['Disabled'] = 'D�sactiv�(e)';
$lang['Enable'] = 'Activer';
$lang['Disable'] = 'D�sactiver';
$lang['AutoLoginSet'] = 'Le cookie de connexion aautomatique a �t� activ�.';
$lang['AutoLoginUnset'] = 'Le cookie de connexion aautomatique a �t� d�sactiv�.';
$lang['RegistrationEmailBody'] = 'Bonjour,

Ceci est un message automatique en provenance de/du [board_name]. Vous venez d\'enregistrer le compte [account_name]. Vous pouvez vous connecter en utilisant votre identifiant et mot de passe.

Identifiant: [account_name]
Mot de passe: [password]

Si vous oubliez votre mot de passe, vous pouvez en demander un nouveau via le formulaire de la page de connexion. Merci de vous �tre enregistr�!

[board_name]
[board_link]
[admin_email]';
$lang['RegistrationEmailSubject'] = 'Enregistrement';
$lang['PublicEmail'] = 'Adresse email publique';
$lang['PublicLastLogin'] = 'Date de derni�re connexion publique';
$lang['DateFormat'] = 'Format de la date';
$lang['DateFormatHelp'] = 'La syntaxe du format de la date correspond � la fonction %s de PHP.';
$lang['Again'] = 'Encore';
$lang['NewPassword'] = 'Nouveau mot de passe';
$lang['NewPasswordAgain'] = 'Nouveau mot de passe (encore)';
$lang['PasswordEdited'] = 'Votre mot de passe a �t� chang� avec succ�s.';
$lang['DetailedOnlineList'] = 'Qui est en ligne? (D�taill�)';
$lang['Detailed'] = 'D�taill�';
$lang['OptionsEdited'] = 'Vos options ont �t� mises � jour avec succ�s.';
$lang['ProfileEdited'] = 'Votre profil a �t� mis � jour avec succ�s.';
$lang['Started'] = 'Commenc�';
$lang['Minutes'] = 'Minutes';
$lang['Hours'] = 'Heures';
$lang['Days'] = 'Jours';
$lang['Weeks'] = 'Semaines';
$lang['TotalTime'] = 'Temps toal';
$lang['NoTopics'] = 'Ce forum ne contient aucun sujet. Vous pourriez poster le premier!';
$lang['NotPermitted'] = 'Vous n\'avez pas les permissions n�cessaires pour cette action. En cas de doute, veuillez contacter l\'administrateur.';
$lang['Language'] = 'Langage';
$lang['Template'] = 'Style';
$lang['NoSuchMember'] = 'Le membre %s n\'existe pas ou plus sur ce forum.';
$lang['FeatureDisabledBecauseCookiesDisabled'] = 'Cette option est d�sactiv�e car le forum ne peut pas �mettre ou lire de cookie avec votre navigateur.';
$lang['LogOutConfirm'] = 'Etes-vous s�r de vouloir vous d�connecter? Votre cookie de connexion automatique sera effac�!';
$lang['Cancel'] = 'Annuler';
$lang['Timezone'] = 'Fuseau horaire';
$lang['DST'] = 'Daylight saving times';
$lang['Sticky'] = 'Post-It';
$lang['PostNewTopic'] = 'Nouveau sujet';
$lang['ForumIsLocked'] = 'Le forum est ferm�';
$lang['NoSuchTopic'] = 'Le sujet %s n\'existe pas (ou plus) sur ce forum.';
$lang['PostReply'] = 'R�pondre';
$lang['TopicIsLocked'] = 'Le sujet est ferm�.';
$lang['Post'] = 'Message';
$lang['Edit'] = 'Editer';
$lang['Delete'] = 'Effacer';
$lang['Quote'] = 'Citer';
$lang['Wrote'] = '%s a �crit';
$lang['ViewingIP'] = 'IP: %s';
$lang['TopicIsLockedExplain'] = 'Le sujet auquel vous essayez de r�pondre est ferm�. Seules les personnes autoris�es peuvent y r�pondre.';
$lang['Content'] = 'Contenu';
$lang['Options'] = 'Options';
$lang['EnableBBCode'] = 'Activer le BBCode.';
$lang['EnableSmilies'] = 'Activer les smileys.';
$lang['EnableSig'] = 'Afficher les signatures.';
$lang['EnableHTML'] = 'Activer le HTML.';
$lang['LockTopicAfterPost'] = 'Fermer le sujet apr�s avoir r�pondu.';
$lang['Guest'] = 'Invit�';
$lang['BackToPrevious'] = 'Retour � la page pr�c�dente';
$lang['NoSuchPost'] = 'Le message %s n\'existe pas (ou plus) sur ce forum.';
$lang['UserPostedImage'] = 'L\'utilisateur a joint une image';
$lang['ForumIsLockedExplain'] = 'Ce forum est ferm�. Seules les personnes autoris�es peuvent y poster.';
$lang['MakeTopicSticky'] = 'Mettre en Post-It.';
$lang['QuickReply'] = 'R�ponse rapide';
$lang['ReturnToTopicAfterPosting'] = 'Retourner au sujet apr�s avoir r�pondu.';
$lang['ModeratorList'] = 'Moderateurs: %s.';
$lang['Nobody'] = 'Personne';
$lang['DeleteTopic'] = 'Supprimer le sujet';
$lang['MoveTopic'] = 'D�placer le sujet';
$lang['LockTopic'] = 'Fermer le sujet';
$lang['UnlockTopic'] = 'Ouvrir le sujet';
$lang['MakeSticky'] = 'Mettre en Post-It';
$lang['ConfirmDeleteTopic'] = 'Etes-vous s�r de vouloir supprimer le sujet %s dans le forum %s? Cette action est irr�versible!';
$lang['MakeNormalTopic'] = 'En faire un sujet normal';
$lang['OldForum'] = 'Ancien forum';
$lang['NewForum'] = 'Nouveau forum';
$lang['IAccept'] = 'J\'accepte';
$lang['IDontAccept'] = 'Je refuse';
$lang['OpenLinksNewWindow'] = 'Ouvrir les liens externes dans de nouvelles fen�tres';
$lang['HideAllAvatars'] = 'Cacher tous les avatars';
$lang['HideUserinfo'] = 'Cacher les infos de l\'utilisateur';
$lang['HideAllSignatures'] = 'Cacher toutes les signatures';
$lang['HideFromOnlineList'] = 'Invisible (Absent de la liste des connect�s)';
$lang['PageLinks'] = 'Page: %s';
$lang['Preview'] = 'Pr�visualisation';
$lang['DeletePost'] = 'Effacer le message';
$lang['ConfirmDeletePost'] = 'Etes-vous s�r de vouloir supprimer ce message dans le sujet %s? Cette action est irr�versible!!';
$lang['EditPost'] = 'Editer le message';
$lang['PostEditInfo'] = 'Derni�re �dition par %s le %s.';
$lang['PasswdInfo'] = 'Le mot de passe ne doit pas contenir d\'espace ou de guillemet. Un minimum de %d caract�res est requis.';
$lang['SubscribeTopic'] = 'S\'abonner';
$lang['UnsubscribeTopic'] = 'Se d�sabboner';
$lang['NewReplyEmailBody'] = 'Bonjour,

Ceci est un message automatique en provenance de/du [board_name]. Quelqu\'un ([poster_name]) a r�pondu � un sujet auquel vous �tes abonn� ("[topic_title]"). Pour voir sa r�ponse, clickez sur le lien suivant: [topic_link].

Clickez sur le lien si vous souhaitez vous d�sabonner de ce sujet (connexion requise): [unsubscribe_link].

[board_name]
[board_link]
[admin_email]';
$lang['NewReplyEmailSubject'] = 'Nouvelle r�ponse dans "%s"';
$lang['SubscribedTopic'] = 'Vous �tes maintenant abonn� � ce sujet.';
$lang['UnsubscribedTopic'] = 'Vous �tes maintenant d�sabonn� de ce sujet.';
$lang['SubscribeToThisTopic'] = 'S\'abonner � ce sujet.';
$lang['OK'] = 'OK';
$lang['Subscriptions'] = 'Abonnements';
$lang['NoSubscribedTopics'] = 'Vous n\�tes pour l\'instant abonn� � aucun sujet.';
$lang['LatestUpdate'] = 'Derni�re mise � jour';
$lang['Unknown'] = 'Inconnu(e)';
$lang['PostingTopic'] = 'Cr�e un nouveau sujet dans %s';
$lang['PostingReply'] = 'R�pond � %s';
$lang['MovingTopic'] = 'D�place le sujet %s';
$lang['DeletingTopic'] = 'Supprime le sujet %s';
$lang['EditingPost'] = 'Edite un message dans %s';
$lang['DeletingPost'] = 'Efface un message dans %s';
$lang['DebugMode'] = 'Debug mode';
$lang['ParseTime'] = 'Temps de chargement';
$lang['ServerLoad'] = 'Charge serveur';
$lang['TemplateSections'] = 'Sections des templates';
$lang['SQLQueries'] = 'Requ�tes SQL';
$lang['RealName'] = 'Nom r��l';
$lang['Skype'] = 'Skype';
$lang['Administrators'] = 'Administrateurs';
$lang['Moderators'] = 'Moderateurs';
$lang['SortBy'] = 'Tri�(s) par: %s';

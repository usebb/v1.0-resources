<?php

/*
	Copyright (C) 2003-2006 UseBB Team
	http://www.usebb.net
	
	$Header$
	
	This file is part of UseBB.
	
	UseBB is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 2 of the License, or
	(at your option) any later version.
	
	UseBB is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.
	
	You should have received a copy of the GNU General Public License
	along with UseBB; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

//
// Die when called directly in browser
// EN-Revision: 1.53
if ( !defined('INCLUDED') )
	exit();

$lang['AdminLogin'] = '管理者ログイン';
$lang['AdminPasswordExplain'] = 'セキュリティ上の理由で ACP へのログインはパスワードを入力しなければなりません。';

$lang['RunningBadACPModule'] = '1 つ以上のアスペクトが見当たらない($usebb_module オブジェクトが見つからない、および(または)見当たらない run_module()オブジェクトメソッドがない)ため、UseBBはこのモジュールを実行することができません。';

$lang['Category-main'] = '全体';
$lang['Item-index'] = ' 一覧';
$lang['Item-version'] = 'バージョンの確認';
$lang['Item-config'] = '全体設定';
$lang['Category-forums'] = 'フォーラム';
$lang['Item-categories'] = 'カテゴリ管理';
$lang['Item-forums'] = 'フォーラム管理';
$lang['Category-various'] = 'その他';
$lang['Item-iplookup'] = 'IP アドレスの照会';
$lang['Item-sqltoolbox'] = 'SQL ツールボックス';
$lang['Item-modules'] = 'ACP モジュール';
$lang['Category-members'] = '会員一覧';
$lang['Item-members'] = '会員の編集';
$lang['Item-delete_members'] = '会員の削除';
$lang['Item-register_members'] = '会員の登録';
$lang['Item-activate_members'] = '会員のアクティベート';
$lang['Item-prune_forums'] = 'フォーラムの除去';

$lang['IndexWelcome'] = 'ようこそ UseBB フォーラムの管理コントロールパネルへ。ここから掲示板のすべての概観の設定、会員やフォーラムの制御などの設定を行うことができます。';
$lang['IndexSystemInfo'] = 'システム情報';
$lang['IndexUseBBVersion'] = 'UseBB バージョン';
$lang['IndexPHPVersion'] = 'PHP バージョン';
$lang['IndexSQLServer'] = 'SQL サーバーのドライバー';
$lang['IndexHTTPServer'] = 'HTTP サーバー';
$lang['IndexOS'] = 'オペレーションシステム';
$lang['IndexLinks'] = 'リンク一覧';
$lang['IndexUnactiveMembers'] = '未アクティベート会員一覧';
$lang['IndexNoUnactiveMembers'] = '管理者のアクティベート待ちの会員は居ません。';
$lang['IndexOneUnactiveMember'] = '管理者のアクティベート待ちの会員が 1 人居ます。';
$lang['IndexMoreUnactiveMembers'] = '管理者のアクティベート待ちの会員が %d 人居ます。';

$lang['VersionFailed'] = 'フォーラムは最新のバージョンを確定することができませんでした。最新のものを使用していること確認するために %s をまめに確認してください。';
$lang['VersionLatestVersionTitle'] = 'これは最新のバージョンです。';
$lang['VersionLatestVersion'] = 'このフォーラムは最新の安定バージョンの UseBB %s でこのフォーラムは動いています。';
$lang['VersionNeedUpdateTitle'] = '新しいバージョンが利用できます。!';
$lang['VersionNeedUpdate'] = 'このフォーラムは UseBB %s ですが、セキュリティ向上とバグ修正のためにバージョン %s にアップデートしてください! 最新バージョンは %s に訪れてダウンロードしてください。';
$lang['VersionBewareDevVersionsTitle'] = '開発バージョンを見つけました。';
$lang['VersionBewareDevVersions'] = 'このフォーラムは「%s」が実行されています。しかしながら最新の安定したバージョンは「%s」です。開発バージョンで存在するかもしれない問題および非互換性に用心してください。';

$lang['ConfigInfo'] = 'このページは UseBB フォーラムのすべての設定を編集できます。注意深くデータベースの設定を変更してください。項目にしるされた「*」は必須項目を表します。';
$lang['ConfigSet'] = '新しい設定を保存しました。新しいページを読み込むと更新されて見えるでしょう。';
$lang['ConfigMissingFields'] = 'いくつかの項目が足りないか正しくありません (例えばテキストは数字が期待されたなど)次の項目を確認してください:';
$lang['ConfigBoard-type'] = '種類';
$lang['ConfigBoard-server'] = 'サーバー';
$lang['ConfigBoard-username'] = 'ユーザー名';
$lang['ConfigBoard-passwd'] = 'パスワード';
$lang['ConfigBoard-dbname'] = 'データベース名';
$lang['ConfigBoard-prefix'] = 'テーブル接頭語';
$lang['ConfigBoardSection-general'] = '掲示板の全般';
$lang['ConfigBoardSection-cookies'] = 'Cookie';
$lang['ConfigBoardSection-sessions'] = 'セッション';
$lang['ConfigBoardSection-page_counts'] = 'ページ数';
$lang['ConfigBoardSection-date_time'] = '日付と時間';
$lang['ConfigBoardSection-database'] = 'データベース設定';
$lang['ConfigBoardSection-advanced'] = '高度な設定';
$lang['ConfigBoardSection-email'] = '電子メール';
$lang['ConfigBoardSection-additional'] = '追加機能';
$lang['ConfigBoardSection-user_rights'] = 'ユーザー権限';
$lang['ConfigBoardSection-layout'] = 'レイアウト設定';
$lang['ConfigBoard-admin_email'] = '管理者の電子メールアドレス';
$lang['ConfigBoard-board_descr'] = '掲示板の詳細';
$lang['ConfigBoard-board_keywords'] = '掲示板のキーワード (カンマ区切り)';
$lang['ConfigBoard-board_name'] = '掲示板名';
$lang['ConfigBoard-date_format'] = '日付の書式';
$lang['ConfigBoard-language'] = 'デフォルト言語';
$lang['ConfigBoard-session_name'] = 'セッション名';
$lang['ConfigBoard-template'] = 'デフォルトテンプレート';
$lang['ConfigBoard-active_topics_count'] = '活発なトピックをカウントする';
$lang['ConfigBoard-avatars_force_width'] = '強制的なアバターの幅 (ピクセル)';
$lang['ConfigBoard-avatars_force_height'] = '強制的なアバターの高さ (ピクセル)';
$lang['ConfigBoard-debug'] = 'デバグモード';
$lang['ConfigBoard-email_view_level'] = '電子メール表示レベル';
$lang['ConfigBoard-flood_interval'] = 'Flood 間隔(単位: 秒)';
$lang['ConfigBoard-members_per_page'] = 'ページ毎の会員数';
$lang['ConfigBoard-online_min_updated'] = 'オンラインユーザーの最終アクセスの間隔';
$lang['ConfigBoard-output_compression'] = '出力の圧縮';
$lang['ConfigBoard-passwd_min_length'] = 'パスワードの最小の長さ';
$lang['ConfigBoard-posts_per_page'] = 'ページ毎の投稿数';
$lang['ConfigBoard-rss_items_count'] = 'RSS 項目数';
$lang['ConfigBoard-search_limit_results'] = '検索結果の制限を x 項目へ';
$lang['ConfigBoard-search_nonindex_words_min_length'] = '検索キーワードの最小の長さ';
$lang['ConfigBoard-session_max_lifetime'] = 'セッションの最大生存時間 (単位: 秒)';
$lang['ConfigBoard-show_edited_message_timeout'] = '投稿の x 秒後に編集された時だけ編集の注意メッセージを表示します。';
$lang['ConfigBoard-topicreview_posts'] = 'トピックレビューの投稿数';
$lang['ConfigBoard-topics_per_page'] = 'ページ毎のトピック数';
$lang['ConfigBoard-view_detailed_online_list_min_level'] = 'オンライン一覧の詳細を閲覧できる最小レベル';
$lang['ConfigBoard-view_forum_stats_box_min_level'] = '統計ボックスを閲覧できる最小レベル';
$lang['ConfigBoard-view_hidden_email_addresses_min_level'] = '電子メールアドレスを隠す最小レベル';
$lang['ConfigBoard-view_memberlist_min_level'] = '会員一覧を閲覧できる最小レベル';
$lang['ConfigBoard-view_stafflist_min_level'] = 'スタッフ一覧を閲覧できる最小レベル';
$lang['ConfigBoard-view_stats_min_level'] = '統計ページを閲覧できる最小レベル';
$lang['ConfigBoard-view_contactadmin_min_level'] = '管理者の連絡先リンクを閲覧できる最小レベル';
$lang['ConfigBoard-allow_multi_sess'] = '単一 IP に複数セッションを許可する';
$lang['ConfigBoard-board_closed'] = 'ボードを閉鎖する';
$lang['ConfigBoard-cookie_secure'] = 'セキュア cookie (HTTPS 用)';
$lang['ConfigBoard-dst'] = 'Daylight saving times';
$lang['ConfigBoard-enable_contactadmin'] = '管理者の連絡先リンクを有効にする';
$lang['ConfigBoard-enable_detailed_online_list'] = 'オンライン一覧の詳細を有効にする';
$lang['ConfigBoard-enable_forum_stats_box'] = '統計ボックスを有効にする';
$lang['ConfigBoard-enable_memberlist'] = '会員一覧を有効にする';
$lang['ConfigBoard-enable_quickreply'] = '簡単な返信を有効にする';
$lang['ConfigBoard-enable_rss'] = 'RSS フィードを有効にする';
$lang['ConfigBoard-enable_stafflist'] = 'スタッフ一覧を有効にする';
$lang['ConfigBoard-enable_stats'] = '統計ページを有効にする';
$lang['ConfigBoard-friendly_urls'] = 'フレンドリー URL を有効にする';
$lang['ConfigBoard-friendly_urls-info'] = 'Apache と mod_rewrite を要求します。URL セッション ID を無効にするでしょう。';
$lang['ConfigBoard-guests_can_access_board'] = 'ゲストが掲示板にアクセスできる';
$lang['ConfigBoard-guests_can_view_profiles'] = 'ゲストが会員のプロフールを閲覧できる';
$lang['ConfigBoard-hide_avatars'] = 'すべてのアバターを隠す';
$lang['ConfigBoard-hide_signatures'] = 'すべての署名を隠す';
$lang['ConfigBoard-hide_userinfo'] = 'ユーザー情報を隠す';
$lang['ConfigBoard-rel_nofollow'] = 'BB コードのリンクの Google 追跡拒否(nofollow)を有効にする';
$lang['ConfigBoard-return_to_topic_after_posting'] = '投稿後にトピックに戻る';
$lang['ConfigBoard-sig_allow_bbcode'] = '署名中の BB コードを有効にする';
$lang['ConfigBoard-sig_allow_smilies'] = '署名中に顔文字を有効にする';
$lang['ConfigBoard-sig_max_length'] = '署名の最大長';
$lang['ConfigBoard-single_forum_mode'] = '単一フォーラムモード (適用可能な場合)';
$lang['ConfigBoard-target_blank'] = 'BB コードのリンクは新しいウィンドウで開く';
$lang['ConfigBoard-users_must_activate'] = 'ユーザーは電子メールでアクティベートしなければならない';
$lang['ConfigBoard-activation_mode'] = 'アクティベーションモード';
$lang['ConfigBoard-activation_mode0'] = 'アクティベーションなし';
$lang['ConfigBoard-activation_mode1'] = '電子メールアクティベーション';
$lang['ConfigBoard-activation_mode2'] = '管理者アクティベーション';
$lang['ConfigBoard-board_closed_reason'] = '掲示板閉鎖の理由';
$lang['ConfigBoard-board_url'] = '掲示板 URL (空だと自動検出)';
$lang['ConfigBoard-cookie_domain'] = 'Cookie ドメイン';
$lang['ConfigBoard-cookie_path'] = 'Cookie パス';
$lang['ConfigBoard-session_save_path'] = 'セッションの保存パス';
$lang['ConfigBoard-exclude_forums_active_topics'] = '活発なトピックから除外するフォーラム';
$lang['ConfigBoard-exclude_forums_rss'] = 'RSS フィードから除外するフォーラム';
$lang['ConfigBoard-exclude_forums_stats'] = '統計ページから除外するフォーラム';
$lang['ConfigBoard-timezone'] = 'タイムゾーン';
$lang['ConfigBoard-debug0'] = '無効';
$lang['ConfigBoard-debug1'] = '簡単なデバグ情報';
$lang['ConfigBoard-debug2'] = '拡張デバグ情報';
$lang['ConfigBoard-email_view_level0'] = 'すべての電子メールアドレスを表示する';
$lang['ConfigBoard-email_view_level1'] = '電子メールフォームを有効にする';
$lang['ConfigBoard-email_view_level2'] = '対 spam 表示をする';
$lang['ConfigBoard-email_view_level3'] = '生で表示する';
$lang['ConfigBoard-output_compression0'] = '無効';
$lang['ConfigBoard-output_compression1'] = 'HTML を圧縮する';
$lang['ConfigBoard-output_compression2'] = 'Gzip を有効にする';
$lang['ConfigBoard-output_compression3'] = 'HTML の圧縮と Gzip を有効にする';
$lang['ConfigBoard-level0'] = 'ゲスト';
$lang['ConfigBoard-level1'] = '会員';
$lang['ConfigBoard-level2'] = 'モデレータ';
$lang['ConfigBoard-level3'] = '管理者';
$lang['ConfigBoard-enable_acp_modules'] = 'ACP モジュール有効';
$lang['ConfigBoard-disable_registrations'] = 'ユーザー登録を無効にする';
$lang['ConfigBoard-disable_registrations_reason'] = 'ユーザー登録を無効にする理由';
$lang['ConfigBoard-allow_duplicate_emails'] = '電子メールアドレスの複製を許可する';

$lang['CategoriesInfo'] = 'このセクションは、掲示板に存在する様々なカテゴリへの制御を提供します。';
$lang['CategoriesAddNewCat'] = '新規カテゴリを追加する';
$lang['CategoriesAdjustSortIDs'] = 'ソート ID の調整';
$lang['CategoriesSortAutomatically'] = '自動でカテゴリをソートする';
$lang['CategoriesNoCatsExist'] = 'この掲示板はまだカテゴリがありません。';
$lang['CategoriesCatName'] = 'カテゴリ名';
$lang['CategoriesSortID'] = 'ソート ID';
$lang['CategoriesMissingFields'] = 'いくつかの必須項目が足りません。それらに正確に記入してください。';
$lang['CategoriesSortChangesApplied'] = 'ソート ID への変更が適用されました。';
$lang['CategoriesConfirmCatDelete'] = 'カテゴリ削除の確認';
$lang['CategoriesConfirmCatDeleteContent'] = '本当にカテゴリ「%s」を削除しますか? この操作は戻せません!';
$lang['CategoriesMoveContents'] = 'カテゴリの内容を %s に移動する';
$lang['CategoriesDeleteContents'] = '内容を削除する';
$lang['CategoriesEditingCat'] = 'カテゴリ %s を編集中';

$lang['ForumsInfo'] = 'このセクションは、掲示板に存在する様々なフォーラムへの制御を提供します。';
$lang['ForumsAddNewForum'] = '新規フォーラムを追加する';
$lang['ForumsAdjustSortIDs'] = 'ソート ID を調整する';
$lang['ForumsSortAutomatically'] = 'フォーラムを自動ソートする';
$lang['ForumsNoForumsExist'] = 'この掲示板はまだフォーラムがありません。';
$lang['ForumsForumName'] = 'フォーラム名';
$lang['ForumsCatName'] = '親カテゴリ';
$lang['ForumsDescription'] = '説明';
$lang['ForumsStatus'] = '状態';
$lang['ForumsStatusOpen'] = '開く';
$lang['ForumsAutoLock'] = 'x 返信後に自動でトピックをロックする';
$lang['ForumsIncreasePostCount'] = 'ユーザーの投稿数を増加する';
$lang['ForumsModerators'] = 'モデレーター';
$lang['ForumsModeratorsExplain'] = 'カンマで区切ったユーザー名(表示名ではありません) 英大小文字を区別しません。';
$lang['ForumsModeratorsUnknown'] = '不明の会員: %s.';
$lang['ForumsHideModsList'] = 'モデレータ一覧を隠す';
$lang['ForumsSortID'] = 'ソート ID';
$lang['ForumsMissingFields'] = 'いくつかの必須項目が足りません。正しく埋めてください。';
$lang['ForumsSortChangesApplied'] = 'ソート ID の変更を適用しました。';
$lang['ForumsConfirmForumDelete'] = 'フォーラム削除の確認';
$lang['ForumsConfirmForumDeleteContent'] = '本当にフォーラム「%s」を削除しますか? この操作は復元できません!';
$lang['ForumsMoveContents'] = 'フォーラムの内容を「%s」に移動する';
$lang['ForumsMoveModerators'] = 'When moving contents, also move moderators.';
$lang['ForumsDeleteContents'] = '内容を削除する';
$lang['ForumsEditingForum'] = 'フォーラム「%s」を編集中';
$lang['ForumsGeneral'] = '一般設定';
$lang['ForumsAuth'] = '認証設定';
$lang['ForumsAuthNote'] = '設定は互いに継承しません。!';
$lang['Forums-level0'] = 'ゲスト';
$lang['Forums-level1'] = '会員';
$lang['Forums-level2'] = 'モデレータ';
$lang['Forums-level3'] = '管理者';
$lang['Forums-auth0'] = 'フォーラムの閲覧';
$lang['Forums-auth1'] = 'トピックを読む';
$lang['Forums-auth2'] = '新規トピックの投稿';
$lang['Forums-auth3'] = 'トピックへの返信';
$lang['Forums-auth4'] = 'その他の投稿の編集';
$lang['Forums-auth5'] = 'トピックの移動';
$lang['Forums-auth6'] = 'トピックと投稿の削除';
$lang['Forums-auth7'] = 'トピックのロック';
$lang['Forums-auth8'] = 'スティッキトピック';
$lang['Forums-auth9'] = 'HTML として投稿 (危険)';

$lang['IPLookupSearchHostname'] = '検索ホスト名';
$lang['IPLookupSearchUsernames'] = '検索ユーザー名';
$lang['IPLookupResult'] = 'IP アドレス %s に対応するホスト名は %s です。';
$lang['IPLookupNotFound'] = '%s に対応するホスト名を見つけることができません。';
$lang['IPLookupUsernamesSingular'] = 'The username %s was used by %s to post messages.';
$lang['IPLookupUsernamesPlural'] = 'The %d usernames %s were used by %s to post messages.';
$lang['IPLookupUsernamesNotFound'] = '%s のユーザー名を見つけることができません。';

$lang['SQLToolboxWarningTitle'] = '重要な警告です!';
$lang['SQLToolboxWarningContent'] = '生の照会ツールは注意深く使ってください。ALTER、DELETE、TRUNCATE もしくは他の種類の照会の実行は取消せず、フォーラムを破損するかもしれません! 何を行うか分かる場合のみこれを使用してください。';
$lang['SQLToolboxExecuteQuery'] = '照会を実行する';
$lang['SQLToolboxExecuteQueryInfo'] = '実行する SQL を入力してください。結果は別のテキストボックスに表示されるでしょう。';
$lang['SQLToolboxExecute'] = '実行する';
$lang['SQLToolboxExecutedSuccessfully'] = '照会の実行に成功しました。';
$lang['SQLToolboxMaintenance'] = 'メンテナンス';
$lang['SQLToolboxMaintenanceInfo'] = 'これらの機能は、UseBB で使用する SQL テーブルを最適化(または修理)します。しばしばテーブルの十分な最適化は大きな掲示板で推奨されます。';
$lang['SQLToolboxRepairTables'] = 'テーブルを修復する';
$lang['SQLToolboxOptimizeTables'] = 'テーブルを最適化する';
$lang['SQLToolboxMaintenanceNote'] = '注意: これはデータベースのロストデータは復元できません。';

$lang['ModulesInfo'] = 'ACP モジュールはサードパーティプログラマーによって作成された機能か私たちの機能で ACP を有用に拡張します。モジュールは、UseBB ウェブサイトにて見つけることができます: %s.';
$lang['ModulesLongName'] = '長い名前';
$lang['ModulesShortName'] = '短い名前';
$lang['ModulesCategory'] = 'カテゴリ';
$lang['ModulesFilename'] = 'ファイル名';
$lang['ModulesDeleteNotPermitted'] = '許可されませんでした。';
$lang['ModulesDisabled'] = '掲示板の設定で ACP モジュールは無効になっています。';
$lang['ModulesNoneAvailable'] = 'モジュールはこの間中に利用可能ではありません。';
$lang['ModulesUpload'] = 'モジュールのアップロード';
$lang['ModulesUploadInfo'] = 'アップロードするために UseBB ACP モジュールのローカルのファイル名を入力します。';
$lang['ModulesUploadDuplicateModule'] = 'ファイル名「%s」というモジュールは既に存在します。それをはじめに削除してください。';
$lang['ModulesUploadNoValidModule'] = 'ファイル「%s」は正しい UseBB モジュールではありません。';
$lang['ModulesUploadFailed'] = 'モジュール %s をインストールできません。コピーに失敗しました。';
$lang['ModulesUploadDisabled'] = 'モジュールディレクトリが書き込めません。アップロードが無効です。有効にし、ディレクトリ「%s」を作成し、ウェブサーバーで書き込めるようにします(chmod 777 を試す)';
$lang['ModulesConfirmModuleDelete'] = 'モジュール削除の確認';
$lang['ModulesConfirmModuleDeleteInfo'] = 'モジュール「%s(%s)」を本当に削除しますか?';

$lang['MembersSearchMember'] = '会員検索';
$lang['MembersSearchMemberInfo'] = '編集するユーザー名か表示名(の一部)を入力します。';
$lang['MembersSearchMemberExplain'] = 'ユーザー名か表示名';
$lang['MembersSearchMemberNotFound'] = '「%s」というユーザー名か表示名では会員が見つかりませんでした。';
$lang['MembersSearchMemberList'] = '次の会員が見つかりました';
$lang['MembersEditingMember'] = '会員「%s」の編集中';
$lang['MembersEditingMemberInfo'] = 'フォームのユーザー情報を送信して更新します。アスタリスク(*)でマークされた項目は必須です。';
$lang['MembersEditingMemberUsernameExists'] = 'ユーザー名「%s」はユーザー名か表示名で既に存在します。';
$lang['MembersEditingMemberDisplayedNameExists'] = '表示名「%s」はユーザー名か表示名で既に存在します。';
$lang['MembersEditingMemberBanned'] = '禁止';
$lang['MembersEditingMemberBannedReason'] = '禁止の理由';
$lang['MembersEditingMemberCantChangeOwnLevel'] = '自分のレベルを変更できません。';
$lang['MembersEditingMemberCantBanSelf'] = '自分自身を禁止にできません。';
$lang['MembersEditingComplete'] = '会員「%s」のプロファイルの編集に成功しました。';

$lang['DeleteMembersSearchMember'] = '会員検索';
$lang['DeleteMembersSearchMemberInfo'] = '削除するユーザー名か表示名(の一部)を入力します。';
$lang['DeleteMembersSearchMemberExplain'] = 'ユーザー名か表示名';
$lang['DeleteMembersSearchMemberNotFound'] = 'ユーザー名か表示名「%s」が会員で見つかりません。';
$lang['DeleteMembersSearchMemberList'] = '次の会員が見つかりました';
$lang['DeleteMembersConfirmMemberDelete'] = '会員削除の確認';
$lang['DeleteMembersConfirmMemberDeleteContent'] = '会員「%s」を本当に削除しますか? これは取り消せません!';
$lang['DeleteMembersComplete'] = '会員「%s」の削除を完了しました。';

$lang['RegisterMembersExplain'] = 'ここで、あらかじめ会員アカウントを登録することができます。アカウントを作成するには、次の情報を埋めてください。';
$lang['RegisterMembersComplete'] = 'ユーザー「%s」の登録を完了しました。ユーザーはすぐにログインすることができます。';

$lang['ActivateMembersExplain'] = 'これはフォーラムの未アクティベートの会員の一覧です。ここで手動でアカウントの承認ができます。アカウントにアスタリスク(*)がマークされたものがアクティブ前です。';
$lang['ActivateMembersNoMembers'] = 'この掲示板に未アクティベートの会員アカウントはありません。';
$lang['ActivateMembersListAdmin'] = '管理者承認';
$lang['ActivateMembersListEmail'] = '電子メール承認';
$lang['ActivateMembersListAll'] = 'すべて';

$lang['PruneForumsStart'] = '除去開始';
$lang['PruneForumsExplain'] = 'フォーラムの除去で、古いトピックを削除するか移動させ、フォーラムをきれいにしておくことができます。';
$lang['PruneForumsForums'] = 'フォーラムを除去する';
$lang['PruneForumsAction'] = '操作';
$lang['PruneForumsActionMove'] = 'トピックを移動する';
$lang['PruneForumsActionDelete'] = 'トピックを削除する';
$lang['PruneForumsMoveTo'] = '次にトピックを移動する';
$lang['PruneForumsTopicAge'] = 'Topic age';
$lang['PruneForumsTopicAgeField'] = '%s 日前に最後の返信です。';
$lang['PruneForumsMoveToForumSelectedForPruning'] = '「移動する」フォーラムは除去に選択できません。';
$lang['PruneForumsConfirm'] = '確認';
$lang['PruneForumsConfirmText'] = 'この操作は戻せないことを理解しました。';
$lang['PruneForumsNotConfirmed'] = 'この操作をはじめに確認する必要があります。';
$lang['PruneForumsDone'] = '除去は完了しました。%d 個のトピックを除去しました。';
$lang['PruneForumsExcludeStickies'] = 'スティッキトピックを除外する';

?>
